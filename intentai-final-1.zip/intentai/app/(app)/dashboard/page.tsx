import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/types/database";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const { data } = await supabase
    .from("profiles")
    .select("display_name")
    .eq("id", user.id)
    .maybeSingle();

  const profile: Pick<Profile, "display_name"> | null = data;

  return (
    <main className="mx-auto flex max-w-3xl flex-col gap-6 px-5 py-10">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold">
          Bonjour {profile?.display_name ?? "toi"} 👋
        </h1>
        <p className="text-zinc-600">
          Explique ce que tu veux obtenir avec une IA : IntentAI t&apos;aide à le formuler.
        </p>
      </div>
      <div>
        <Link
          href="/new"
          className="inline-block rounded-xl bg-indigo-600 px-5 py-3 text-sm font-medium text-white transition-colors hover:bg-indigo-500"
        >
          Nouvelle idée
        </Link>
      </div>
    </main>
  );
}
