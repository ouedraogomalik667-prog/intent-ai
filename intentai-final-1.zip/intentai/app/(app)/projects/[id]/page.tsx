import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { AnalysisPipeline } from "@/components/project/AnalysisPipeline";
import { InstructionWorkspace } from "@/components/project/InstructionWorkspace";
import { InstructionPipeline } from "@/components/project/InstructionPipeline";
import { IntentSummary } from "@/components/project/IntentSummary";
import { QuestionsForm } from "@/components/project/QuestionsForm";
import { CATEGORIES } from "@/lib/constants";
import { projectIdSchema } from "@/lib/project-schemas";
import { getVersionHistory } from "@/lib/services/feedback";
import { getCurrentInstruction } from "@/lib/services/instructions";
import { getAnswers, getProject, readStoredIntent } from "@/lib/services/projects";
import { createClient } from "@/lib/supabase/server";

export default async function ProjectPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  if (!projectIdSchema.safeParse(id).success) notFound();

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  // La RLS renvoie null pour le projet d'un autre utilisateur : page 404.
  const project = await getProject(supabase, id);
  if (!project) notFound();

  const stored = readStoredIntent(project);
  const questions = stored?.questions ?? null;
  const isFinished = project.status === "ready" || project.status === "completed";
  const answers = isFinished ? await getAnswers(supabase, project.id) : [];
  const current = isFinished ? await getCurrentInstruction(supabase, project.id) : null;
  const versions = current ? await getVersionHistory(supabase, current.instruction.id) : [];
  const category = CATEGORIES.find((item) => item.id === project.category);

  return (
    <main className="mx-auto flex max-w-2xl flex-col gap-6 px-5 py-10">
      <Link href="/dashboard" className="text-sm text-zinc-500 hover:text-zinc-800">
        ← Dashboard
      </Link>

      <header className="flex flex-col gap-2">
        {category && (
          <span className="text-xs font-medium text-indigo-700">
            {category.emoji} {category.label}
          </span>
        )}
        <h1 className="text-2xl font-bold">{project.title ?? "Mon projet"}</h1>
      </header>

      <section className="flex flex-col gap-1 rounded-2xl bg-zinc-50 p-5">
        <h2 className="text-xs font-medium uppercase tracking-wide text-zinc-500">Mon idée</h2>
        <p className="text-sm">{project.original_idea}</p>
      </section>

      {!stored || questions === null ? (
        <AnalysisPipeline projectId={project.id} needsAnalysis={!stored} />
      ) : (
        <>
          <IntentSummary analysis={stored.analysis} />

          {project.status === "questioning" && (
            <QuestionsForm projectId={project.id} questions={questions} />
          )}

          {isFinished && (
            <>
              {questions.length === 0 ? (
                <p className="rounded-2xl border border-zinc-200 p-5 text-sm text-zinc-700">
                  Ton idée est assez claire : aucune question n&apos;était nécessaire.
                </p>
              ) : (
                <section className="flex flex-col gap-3 rounded-2xl border border-zinc-200 p-5">
                  <h2 className="font-semibold">Tes réponses</h2>
                  {questions.map((question, index) => (
                    <div key={question.id} className="flex flex-col gap-0.5 text-sm">
                      <span className="text-zinc-500">{question.text}</span>
                      <span>{answers[index] ?? "—"}</span>
                    </div>
                  ))}
                </section>
              )}

              {current ? (
                <>
                  <InstructionWorkspace
                    key={current.version.version_number}
                    projectId={project.id}
                    currentVersion={current.version.version_number}
                    versions={versions}
                  />
                  <Link
                    href="/dashboard"
                    className="rounded-xl border border-zinc-300 px-5 py-3 text-center text-sm font-medium text-zinc-800 transition-colors hover:bg-zinc-100"
                  >
                    Retour au dashboard
                  </Link>
                </>
              ) : (
                <InstructionPipeline projectId={project.id} />
              )}
            </>
          )}
        </>
      )}
    </main>
  );
}
