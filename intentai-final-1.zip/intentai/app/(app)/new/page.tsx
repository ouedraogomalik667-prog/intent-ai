import { NewProjectForm } from "@/components/project/NewProjectForm";

export default function NewProjectPage() {
  return (
    <main className="mx-auto flex max-w-2xl flex-col gap-6 px-5 py-10">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold">Nouvelle idée</h1>
        <p className="text-zinc-600">
          Explique ce que tu veux avec tes propres mots. IntentAI s&apos;occupe du reste.
        </p>
      </div>
      <NewProjectForm />
    </main>
  );
}
