"use server";

import type { AuthError } from "@supabase/supabase-js";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { loginSchema, signupSchema } from "@/lib/validation";
import type { AuthState } from "@/types/auth";

function translateAuthError(error: AuthError): string {
  switch (error.code) {
    case "invalid_credentials":
      return "Email ou mot de passe incorrect.";
    case "email_not_confirmed":
      return "Confirme d'abord ton adresse email (vérifie ta boîte mail).";
    case "user_already_exists":
      return "Un compte existe déjà avec cet email. Connecte-toi.";
    case "weak_password":
      return "Mot de passe trop faible : choisis-en un plus long ou plus complexe.";
    case "over_request_rate_limit":
    case "over_email_send_rate_limit":
      return "Trop de tentatives. Réessaie dans quelques minutes.";
    default:
      return "Une erreur est survenue. Réessaie dans un instant.";
  }
}

function fail(error: string, email: string, displayName = ""): AuthState {
  return { error, message: null, email, displayName };
}

export async function login(
  _prevState: AuthState,
  formData: FormData
): Promise<AuthState> {
  const email = String(formData.get("email") ?? "");
  const password = String(formData.get("password") ?? "");

  const parsed = loginSchema.safeParse({ email, password });
  if (!parsed.success) {
    return fail(parsed.error.issues[0]?.message ?? "Données invalides.", email);
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword(parsed.data);
  if (error) {
    return fail(translateAuthError(error), email);
  }

  redirect("/dashboard");
}

export async function signup(
  _prevState: AuthState,
  formData: FormData
): Promise<AuthState> {
  const displayName = String(formData.get("displayName") ?? "");
  const email = String(formData.get("email") ?? "");
  const password = String(formData.get("password") ?? "");

  const parsed = signupSchema.safeParse({ displayName, email, password });
  if (!parsed.success) {
    return fail(
      parsed.error.issues[0]?.message ?? "Données invalides.",
      email,
      displayName
    );
  }

  const headerList = await headers();
  const origin = headerList.get("origin") ?? "http://localhost:3000";

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      data: { display_name: parsed.data.displayName },
      emailRedirectTo: `${origin}/auth/callback`,
    },
  });

  if (error) {
    return fail(translateAuthError(error), email, displayName);
  }

  // Confirmation email désactivée : la session existe déjà.
  if (data.session) {
    redirect("/dashboard");
  }

  // Confirmation email activée : il faut cliquer sur le lien reçu.
  return {
    error: null,
    message:
      "Compte créé. Vérifie ta boîte mail pour confirmer ton adresse, puis connecte-toi.",
    email,
    displayName,
  };
}

export async function logout(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}
