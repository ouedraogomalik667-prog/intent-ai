import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const TABLES = [
  "profiles",
  "projects",
  "project_messages",
  "instructions",
  "instruction_versions",
  "feedback",
] as const;

export async function GET() {
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  try {
    const supabase = await createClient();

    const results = await Promise.all(
      TABLES.map(async (table) => {
        const { count, error } = await supabase
          .from(table)
          .select("*", { count: "exact", head: true });
        return {
          table,
          reachable: !error,
          visibleRows: count ?? 0,
          error: error?.message ?? null,
        };
      })
    );

    const allOk = results.every((r) => r.reachable);
    return NextResponse.json(
      { status: allOk ? "ok" : "error", results },
      { status: allOk ? 200 : 500 }
    );
  } catch (e) {
    const message = e instanceof Error ? e.message : "Erreur inconnue";
    return NextResponse.json({ status: "error", message }, { status: 500 });
  }
}
