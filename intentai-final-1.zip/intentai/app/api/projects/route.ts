import { NextResponse } from "next/server";
import { getAuthContext, handleRouteError, jsonError, readJson } from "@/lib/api-utils";
import { createProjectSchema } from "@/lib/project-schemas";
import { createProject } from "@/lib/services/projects";

export async function POST(request: Request) {
  try {
    const ctx = await getAuthContext();
    if (!ctx) return jsonError("Non connecté.", 401);

    const parsed = createProjectSchema.safeParse(await readJson(request));
    if (!parsed.success) {
      const issue = parsed.error.issues[0];
      const message =
        issue?.path[0] === "category"
          ? "Choisis une catégorie."
          : (issue?.message ?? "Données invalides.");
      return jsonError(message, 400);
    }

    const project = await createProject(ctx.supabase, ctx.user.id, {
      category: parsed.data.category,
      idea: parsed.data.idea,
    });
    return NextResponse.json({ id: project.id }, { status: 201 });
  } catch (error) {
    return handleRouteError(error);
  }
}
