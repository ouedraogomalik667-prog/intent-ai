import { NextResponse } from "next/server";
import { z } from "zod";
import { getAIProvider } from "@/lib/ai";
import { questionSchema } from "@/lib/ai/schemas";
import { getAuthContext, handleRouteError, jsonError } from "@/lib/api-utils";
import { projectIdSchema } from "@/lib/project-schemas";
import { getProject, readStoredIntent, saveQuestions } from "@/lib/services/projects";

export async function POST(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const ctx = await getAuthContext();
    if (!ctx) return jsonError("Non connecté.", 401);

    const { id } = await params;
    const idParsed = projectIdSchema.safeParse(id);
    if (!idParsed.success) return jsonError("Identifiant de projet invalide.", 400);

    const project = await getProject(ctx.supabase, idParsed.data);
    if (!project) return jsonError("Projet introuvable.", 404);

    const stored = readStoredIntent(project);
    if (!stored) {
      return jsonError("L'analyse de l'idée doit être faite avant les questions.", 409);
    }
    if (stored.questions !== null) {
      return NextResponse.json({ questions: stored.questions, status: project.status });
    }

    const raw = await getAIProvider().generateQuestions({ analysis: stored.analysis });
    const known = new Set(stored.analysis.providedInformation.map((info) => info.key));
    const questions = z
      .array(questionSchema)
      .parse(raw)
      .filter((question) => !known.has(question.id))
      .slice(0, 3);

    const status = await saveQuestions(
      ctx.supabase,
      ctx.user.id,
      project.id,
      stored.analysis,
      questions
    );
    return NextResponse.json({ questions, status });
  } catch (error) {
    return handleRouteError(error);
  }
}
