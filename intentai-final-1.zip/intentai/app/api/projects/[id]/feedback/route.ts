import { NextResponse } from "next/server";
import { z } from "zod";
import { getAIProvider } from "@/lib/ai";
import { getAuthContext, handleRouteError, jsonError, readJson } from "@/lib/api-utils";
import { projectIdSchema } from "@/lib/project-schemas";
import {
  createImprovedInstructionVersion,
  savePositiveFeedback,
  toQuestionAnswers,
} from "@/lib/services/feedback";
import { getCurrentInstruction } from "@/lib/services/instructions";
import { getAnswers, getProject, readStoredIntent } from "@/lib/services/projects";

const bodySchema = z.discriminatedUnion("isPositive", [
  z.object({ isPositive: z.literal(true), versionNumber: z.number().int().min(1) }),
  z.object({
    isPositive: z.literal(false),
    versionNumber: z.number().int().min(1),
    comment: z.string().trim().min(3).max(1000),
  }),
]);

const COMMENT_REQUIRED = "Explique en quelques mots ce qui ne convient pas dans cette instruction.";
const COMMENT_TOO_LONG = "Ton retour est trop long (1000 caractères maximum).";

function versionConflict(message: string) {
  return NextResponse.json({ error: message, code: "version_conflict" }, { status: 409 });
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const ctx = await getAuthContext();
    if (!ctx) return jsonError("Non connecté.", 401);

    const { id } = await params;
    const idParsed = projectIdSchema.safeParse(id);
    if (!idParsed.success) return jsonError("Identifiant de projet invalide.", 400);

    const body = bodySchema.safeParse(await readJson(request));
    if (!body.success) {
      const problem = body.error.issues[0];
      if (problem?.path[0] === "comment") {
        return jsonError(problem.code === "too_big" ? COMMENT_TOO_LONG : COMMENT_REQUIRED, 400);
      }
      return jsonError("Données invalides.", 400);
    }

    // La RLS renvoie null pour le projet d'un autre utilisateur : 404.
    const project = await getProject(ctx.supabase, idParsed.data);
    if (!project) return jsonError("Projet introuvable.", 404);

    const current = await getCurrentInstruction(ctx.supabase, project.id);
    if (!current || project.status !== "completed") {
      return jsonError("Génère d'abord ton instruction avant de donner ton avis.", 409);
    }

    // Le retour doit porter sur la version réellement affichée.
    if (current.version.version_number !== body.data.versionNumber) {
      return versionConflict("Une version plus récente existe. Recharge la page pour la voir.");
    }

    // 👍 : on enregistre le feedback, rien d'autre.
    if (body.data.isPositive) {
      const result = await savePositiveFeedback(ctx.supabase, ctx.user.id, current.version.id);
      if (result === "conflict") {
        return versionConflict("Cette version a déjà reçu un retour. Recharge la page.");
      }
      return NextResponse.json(
        { status: "validated", version: current.version.version_number },
        { status: result === "saved" ? 201 : 200 }
      );
    }

    // 👎 : analyse du retour + création de la version suivante (transaction SQL).
    const stored = readStoredIntent(project);
    if (!stored || stored.questions === null) {
      return jsonError("L'analyse de ton idée est incomplète.", 409);
    }
    const savedAnswers = await getAnswers(ctx.supabase, project.id);

    const result = await createImprovedInstructionVersion(ctx.supabase, getAIProvider(), {
      projectId: project.id,
      category: project.category,
      idea: project.original_idea,
      analysis: stored.analysis,
      answers: toQuestionAnswers(stored, savedAnswers),
      baseVersionNumber: body.data.versionNumber,
      feedback: body.data.comment,
    });
    if (result.status === "conflict") {
      return versionConflict("Cette version a déjà reçu un retour. Recharge la page.");
    }

    return NextResponse.json(
      {
        status: "improved",
        version: result.current.version.version_number,
        summary: result.current.version.change_summary,
      },
      { status: 201 }
    );
  } catch (error) {
    return handleRouteError(error);
  }
}
