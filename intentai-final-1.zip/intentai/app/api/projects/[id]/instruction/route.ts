import { NextResponse } from "next/server";
import { z } from "zod";
import { getAIProvider } from "@/lib/ai";
import type { QuestionAnswer } from "@/lib/ai/types";
import { getAuthContext, handleRouteError, jsonError } from "@/lib/api-utils";
import { projectIdSchema } from "@/lib/project-schemas";
import {
  getCurrentInstruction,
  markProjectCompleted,
  saveFirstInstruction,
} from "@/lib/services/instructions";
import { getAnswers, getProject, readStoredIntent } from "@/lib/services/projects";

const builtInstructionSchema = z.object({
  content: z.string().min(1).max(20000),
  summary: z.string().min(1).max(500),
});

export async function POST(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const ctx = await getAuthContext();
    if (!ctx) return jsonError("Non connecté.", 401);

    const { id } = await params;
    const idParsed = projectIdSchema.safeParse(id);
    if (!idParsed.success) return jsonError("Identifiant de projet invalide.", 400);

    // La RLS renvoie null pour le projet d'un autre utilisateur.
    const project = await getProject(ctx.supabase, idParsed.data);
    if (!project) return jsonError("Projet introuvable.", 404);

    if (project.status !== "ready" && project.status !== "completed") {
      return jsonError("Réponds d'abord aux questions pour obtenir ton instruction.", 409);
    }

    // Déjà générée : on ne refait rien (pas de nouvelle version).
    const existing = await getCurrentInstruction(ctx.supabase, project.id);
    if (existing) {
      if (project.status !== "completed") {
        await markProjectCompleted(ctx.supabase, project.id);
      }
      return NextResponse.json({ version: existing.version.version_number });
    }

    const stored = readStoredIntent(project);
    if (!stored || stored.questions === null) {
      return jsonError("L'analyse de ton idée est incomplète.", 409);
    }

    const savedAnswers = await getAnswers(ctx.supabase, project.id);
    if (savedAnswers.length < stored.questions.length) {
      return jsonError("Il manque des réponses aux questions.", 409);
    }

    const answers: QuestionAnswer[] = stored.questions.map((question, index) => ({
      key: question.id,
      question: question.text,
      answer: savedAnswers[index] ?? "Pas de préférence.",
    }));

    const raw = await getAIProvider().buildInstruction({
      idea: project.original_idea,
      analysis: stored.analysis,
      answers,
    });
    const built = builtInstructionSchema.parse(raw);

    const saved = await saveFirstInstruction(ctx.supabase, ctx.user.id, project.id, built);
    await markProjectCompleted(ctx.supabase, project.id);

    return NextResponse.json({ version: saved.version.version_number }, { status: 201 });
  } catch (error) {
    return handleRouteError(error);
  }
}
