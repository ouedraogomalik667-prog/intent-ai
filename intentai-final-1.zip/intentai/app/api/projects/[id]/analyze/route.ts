import { NextResponse } from "next/server";
import { getAIProvider } from "@/lib/ai";
import { intentAnalysisSchema } from "@/lib/ai/schemas";
import { getAuthContext, handleRouteError, jsonError } from "@/lib/api-utils";
import { projectIdSchema } from "@/lib/project-schemas";
import { getProject, readStoredIntent, saveAnalysis } from "@/lib/services/projects";

export async function POST(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const ctx = await getAuthContext();
    if (!ctx) return jsonError("Non connecté.", 401);

    const { id } = await params;
    const idParsed = projectIdSchema.safeParse(id);
    if (!idParsed.success) return jsonError("Identifiant de projet invalide.", 400);

    const project = await getProject(ctx.supabase, idParsed.data);
    if (!project) return jsonError("Projet introuvable.", 404);

    const existing = readStoredIntent(project);
    if (existing) {
      return NextResponse.json({ analysis: existing.analysis });
    }

    const raw = await getAIProvider().analyzeIntent({
      idea: project.original_idea,
      category: project.category,
    });
    const analysis = intentAnalysisSchema.parse(raw);

    await saveAnalysis(ctx.supabase, project.id, analysis);
    return NextResponse.json({ analysis });
  } catch (error) {
    return handleRouteError(error);
  }
}
