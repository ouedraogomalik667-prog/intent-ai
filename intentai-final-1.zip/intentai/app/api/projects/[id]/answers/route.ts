import { NextResponse } from "next/server";
import { getAuthContext, handleRouteError, jsonError, readJson } from "@/lib/api-utils";
import { answersSchema, projectIdSchema } from "@/lib/project-schemas";
import { getProject, readStoredIntent, saveAnswers } from "@/lib/services/projects";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const ctx = await getAuthContext();
    if (!ctx) return jsonError("Non connecté.", 401);

    const { id } = await params;
    const idParsed = projectIdSchema.safeParse(id);
    if (!idParsed.success) return jsonError("Identifiant de projet invalide.", 400);

    const body = answersSchema.safeParse(await readJson(request));
    if (!body.success) {
      return jsonError(body.error.issues[0]?.message ?? "Données invalides.", 400);
    }

    const project = await getProject(ctx.supabase, idParsed.data);
    if (!project) return jsonError("Projet introuvable.", 404);

    if (project.status === "ready" || project.status === "completed") {
      return NextResponse.json({ status: project.status });
    }

    const stored = readStoredIntent(project);
    const questions = stored?.questions ?? [];
    if (project.status !== "questioning" || questions.length === 0) {
      return jsonError("Ce projet n'attend pas de réponses.", 409);
    }
    if (body.data.answers.length !== questions.length) {
      return jsonError("Il manque des réponses.", 400);
    }

    const answers = body.data.answers.map((answer) =>
      answer.length > 0 ? answer : "Pas de préférence."
    );
    await saveAnswers(ctx.supabase, ctx.user.id, project.id, answers);

    return NextResponse.json({ status: "ready" });
  } catch (error) {
    return handleRouteError(error);
  }
}
