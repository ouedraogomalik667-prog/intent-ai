import { NextResponse } from "next/server";
import { APP_NAME, getAiProviderName } from "@/lib/env";

export async function GET() {
  return NextResponse.json({
    status: "ok",
    app: APP_NAME,
    aiProvider: getAiProviderName(),
  });
}
