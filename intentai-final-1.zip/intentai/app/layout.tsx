import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "IntentAI",
  description:
    "Tu sais ce que tu veux. Explique-le simplement : IntentAI le transforme en instruction claire pour l'IA.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body className="min-h-screen bg-white text-zinc-900 antialiased">
        {children}
      </body>
    </html>
  );
}
