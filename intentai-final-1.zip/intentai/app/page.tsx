import Link from "next/link";
import { CATEGORIES } from "@/lib/constants";
import { APP_NAME } from "@/lib/env";

export default function HomePage() {
  return (
    <main className="mx-auto flex max-w-2xl flex-col gap-10 px-5 py-16">
      <header className="flex flex-col gap-4">
        <span className="text-sm font-semibold text-indigo-600">{APP_NAME}</span>
        <h1 className="text-3xl font-bold leading-tight sm:text-4xl">
          Tu sais ce que tu veux.
          <br />
          Explique-le simplement.
        </h1>
        <p className="text-zinc-600">
          {APP_NAME} transforme ton intention en instruction claire pour l&apos;IA
          et t&apos;accompagne jusqu&apos;au résultat souhaité.
        </p>
        <div className="flex flex-wrap gap-3">
          <Link
            href="/signup"
            className="rounded-xl bg-indigo-600 px-5 py-3 text-sm font-medium text-white transition-colors hover:bg-indigo-500"
          >
            Commencer
          </Link>
          <Link
            href="/login"
            className="rounded-xl border border-zinc-300 px-5 py-3 text-sm font-medium text-zinc-800 transition-colors hover:bg-zinc-100"
          >
            Se connecter
          </Link>
        </div>
      </header>

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {CATEGORIES.map((c) => (
          <div key={c.id} className="rounded-2xl border border-zinc-200 p-4">
            <div className="text-2xl">{c.emoji}</div>
            <div className="mt-2 text-sm font-medium">{c.label}</div>
          </div>
        ))}
      </section>
    </main>
  );
}
