import { AuthForm } from "@/components/auth/AuthForm";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const { error } = await searchParams;
  const notice =
    error === "confirmation"
      ? "Le lien de confirmation est invalide ou expiré. Reconnecte-toi ou recrée ton compte."
      : undefined;

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-10">
      <AuthForm mode="login" notice={notice} />
    </main>
  );
}
