// Fonctions pures utilisées par l'interface du feedback (faciles à tester).

export const COMMENT_MIN = 3;
export const COMMENT_MAX = 1000;

export interface FeedbackApiResponse {
  error?: string;
  code?: string;
}

// Retourne un message d'erreur, ou null si le commentaire est valide.
export function validateComment(raw: string): string | null {
  const length = raw.trim().length;
  if (length < COMMENT_MIN) {
    return "Explique en quelques mots ce qui ne va pas (3 caractères minimum).";
  }
  if (length > COMMENT_MAX) {
    return "Ton retour est trop long (1000 caractères maximum).";
  }
  return null;
}

// Messages propres : jamais de détail technique pour les erreurs serveur.
export function describeFeedbackError(status: number, data: FeedbackApiResponse): string {
  if (status === 401) return "Ta session a expiré. Reconnecte-toi pour continuer.";
  if (status === 404) return "Ce projet est introuvable.";
  if (status >= 500) return "Un problème est survenu de notre côté. Réessaie dans un instant.";
  return data.error ?? "Une erreur est survenue. Réessaie.";
}

export function isVersionConflict(data: FeedbackApiResponse): boolean {
  return data.code === "version_conflict";
}

// Le résumé vient du backend (« Ton ... ; public cible précisé : ... ») : on le découpe en puces.
export function splitSummary(summary: string | null): string[] {
  if (!summary) return [];
  return summary
    .replace(/\.\s*$/, "")
    .split(" ; ")
    .map((part) => part.trim())
    .filter((part) => part.length > 0)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1));
}
