import { NextResponse } from "next/server";
import { AIProviderError } from "@/lib/ai/provider";
import { createClient } from "@/lib/supabase/server";

export function jsonError(message: string, status: number) {
  return NextResponse.json({ error: message }, { status });
}

export async function getAuthContext() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;
  return { supabase, user };
}

export async function readJson(request: Request): Promise<unknown> {
  try {
    return await request.json();
  } catch {
    return null;
  }
}

export function handleRouteError(error: unknown) {
  console.error(error);
  if (error instanceof AIProviderError) {
    return jsonError(error.message, 503);
  }
  return jsonError("Une erreur est survenue. Réessaie dans un instant.", 500);
}
