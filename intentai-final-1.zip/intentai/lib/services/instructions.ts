import type { SupabaseClient } from "@supabase/supabase-js";
import type { Instruction, InstructionVersion } from "@/types/database";

export interface CurrentInstruction {
  instruction: Instruction;
  version: InstructionVersion;
}

interface BuiltContent {
  content: string;
  summary: string;
}

// Code PostgreSQL « violation de contrainte d'unicité » : quelqu'un a déjà créé la ligne.
function isUniqueViolation(error: { code?: string } | null): boolean {
  return error?.code === "23505";
}

async function findInstruction(
  supabase: SupabaseClient,
  projectId: string
): Promise<Instruction | null> {
  const { data, error } = await supabase
    .from("instructions")
    .select("*")
    .eq("project_id", projectId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as Instruction | null) ?? null;
}

// Retourne l'instruction et sa version courante (celle indiquée par current_version).
// Les futures améliorations (étape suivante) créeront la version N+1 puis mettront
// current_version à jour : cette lecture n'aura pas besoin de changer.
export async function getCurrentInstruction(
  supabase: SupabaseClient,
  projectId: string
): Promise<CurrentInstruction | null> {
  const instruction = await findInstruction(supabase, projectId);
  if (!instruction) return null;

  const { data, error } = await supabase
    .from("instruction_versions")
    .select("*")
    .eq("instruction_id", instruction.id)
    .eq("version_number", instruction.current_version)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) return null;

  return { instruction, version: data as InstructionVersion };
}

// Crée l'instruction + la version 1, sans jamais écraser quoi que ce soit :
// - instruction déjà complète (version courante existante) -> renvoyée telle quelle, rien n'est écrit ;
// - ligne instruction déjà créée (même par un appel simultané) -> réutilisée ;
// - version 1 déjà créée par un appel simultané -> conservée (l'insertion en double est ignorée) ;
// - ligne instruction sans version (erreur précédente) -> la version 1 est créée.
export async function saveFirstInstruction(
  supabase: SupabaseClient,
  userId: string,
  projectId: string,
  built: BuiltContent
): Promise<CurrentInstruction> {
  // 1. Déjà complète : on ne touche à rien.
  const existing = await getCurrentInstruction(supabase, projectId);
  if (existing) return existing;

  // 2. Ligne « instruction » (une seule par projet grâce à la contrainte unique).
  let instruction = await findInstruction(supabase, projectId);
  if (!instruction) {
    const { data, error } = await supabase
      .from("instructions")
      .insert({ project_id: projectId, user_id: userId, current_version: 1 })
      .select("*")
      .single();

    if (error) {
      if (!isUniqueViolation(error)) throw new Error(error.message);
      instruction = await findInstruction(supabase, projectId);
    } else {
      instruction = data as Instruction;
    }
  }
  if (!instruction) throw new Error("Instruction introuvable après création.");

  // 3. Seule la version 1 peut être créée ici. Si l'instruction pointe déjà vers
  //    une autre version manquante, on s'arrête plutôt que d'inventer du contenu.
  if (instruction.current_version !== 1) {
    throw new Error("La version courante de cette instruction est introuvable.");
  }

  const { error: versionError } = await supabase.from("instruction_versions").insert({
    instruction_id: instruction.id,
    user_id: userId,
    version_number: 1,
    content: built.content,
    change_summary: built.summary,
  });
  if (versionError && !isUniqueViolation(versionError)) {
    throw new Error(versionError.message);
  }

  const current = await getCurrentInstruction(supabase, projectId);
  if (!current) throw new Error("Version introuvable après création.");
  return current;
}

export async function markProjectCompleted(
  supabase: SupabaseClient,
  projectId: string
): Promise<void> {
  const { error } = await supabase
    .from("projects")
    .update({ status: "completed" })
    .eq("id", projectId);
  if (error) throw new Error(error.message);
}
