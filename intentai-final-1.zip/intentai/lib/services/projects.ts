import type { SupabaseClient } from "@supabase/supabase-js";
import { storedIntentSchema } from "@/lib/ai/schemas";
import type { IntentAnalysis, Question, StoredIntent } from "@/lib/ai/types";
import type { CategoryId } from "@/types";
import type { Project, ProjectStatus } from "@/types/database";

function makeTitle(idea: string): string {
  const clean = idea.trim().replace(/\s+/g, " ");
  return clean.length > 60 ? `${clean.slice(0, 57)}...` : clean;
}

export async function createProject(
  supabase: SupabaseClient,
  userId: string,
  input: { category: CategoryId; idea: string }
): Promise<Project> {
  const { data, error } = await supabase
    .from("projects")
    .insert({
      user_id: userId,
      category: input.category,
      original_idea: input.idea,
      title: makeTitle(input.idea),
      status: "draft",
    })
    .select("*")
    .single();
  if (error) throw new Error(error.message);
  return data as Project;
}

// Retourne null si le projet n'existe pas OU appartient à un autre utilisateur (RLS).
export async function getProject(
  supabase: SupabaseClient,
  projectId: string
): Promise<Project | null> {
  const { data, error } = await supabase
    .from("projects")
    .select("*")
    .eq("id", projectId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as Project | null) ?? null;
}

export function readStoredIntent(project: Project): StoredIntent | null {
  const parsed = storedIntentSchema.safeParse(project.intent);
  return parsed.success ? parsed.data : null;
}

async function updateProject(
  supabase: SupabaseClient,
  projectId: string,
  patch: { intent?: StoredIntent; status?: ProjectStatus }
): Promise<void> {
  const { data, error } = await supabase
    .from("projects")
    .update(patch)
    .eq("id", projectId)
    .select("id");
  if (error) throw new Error(error.message);
  if (!data || data.length === 0) throw new Error("Projet introuvable.");
}

export async function saveAnalysis(
  supabase: SupabaseClient,
  projectId: string,
  analysis: IntentAnalysis
): Promise<void> {
  await updateProject(supabase, projectId, { intent: { analysis, questions: null } });
}

export async function saveQuestions(
  supabase: SupabaseClient,
  userId: string,
  projectId: string,
  analysis: IntentAnalysis,
  questions: Question[]
): Promise<ProjectStatus> {
  const status: ProjectStatus = questions.length > 0 ? "questioning" : "ready";
  await updateProject(supabase, projectId, { intent: { analysis, questions }, status });

  if (questions.length > 0) {
    const base = Date.now();
    const { error } = await supabase.from("project_messages").insert(
      questions.map((question, index) => ({
        project_id: projectId,
        user_id: userId,
        role: "assistant",
        content: question.text,
        created_at: new Date(base + index).toISOString(),
      }))
    );
    if (error) throw new Error(error.message);
  }
  return status;
}

export async function saveAnswers(
  supabase: SupabaseClient,
  userId: string,
  projectId: string,
  answers: string[]
): Promise<void> {
  // On efface d'éventuelles réponses précédentes : l'opération est rejouable sans doublon.
  const { error: deleteError } = await supabase
    .from("project_messages")
    .delete()
    .eq("project_id", projectId)
    .eq("role", "user");
  if (deleteError) throw new Error(deleteError.message);

  const base = Date.now();
  const { error: insertError } = await supabase.from("project_messages").insert(
    answers.map((answer, index) => ({
      project_id: projectId,
      user_id: userId,
      role: "user",
      content: answer,
      created_at: new Date(base + index).toISOString(),
    }))
  );
  if (insertError) throw new Error(insertError.message);

  await updateProject(supabase, projectId, { status: "ready" });
}

export async function getAnswers(
  supabase: SupabaseClient,
  projectId: string
): Promise<string[]> {
  const { data, error } = await supabase
    .from("project_messages")
    .select("content")
    .eq("project_id", projectId)
    .eq("role", "user")
    .order("created_at", { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []).map((row: { content: string }) => row.content);
}
