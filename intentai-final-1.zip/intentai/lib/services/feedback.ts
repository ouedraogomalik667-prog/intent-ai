import type { SupabaseClient } from "@supabase/supabase-js";
import { builtInstructionSchema, feedbackAnalysisSchema } from "@/lib/ai/feedback-schemas";
import type { AIProvider } from "@/lib/ai/provider";
import type { IntentAnalysis, QuestionAnswer, StoredIntent } from "@/lib/ai/types";
import { getCurrentInstruction, type CurrentInstruction } from "@/lib/services/instructions";
import type { CategoryId } from "@/types";
import type { Feedback, InstructionVersion } from "@/types/database";

// Code PostgreSQL « violation de contrainte d'unicité » : un feedback existe déjà pour cette version.
function isUniqueViolation(error: { code?: string } | null): boolean {
  return error?.code === "23505";
}

// Associe chaque réponse à sa question (même ordre que les questions enregistrées).
export function toQuestionAnswers(stored: StoredIntent, saved: string[]): QuestionAnswer[] {
  return (stored.questions ?? []).map((question, index) => ({
    key: question.id,
    question: question.text,
    answer: saved[index] ?? "Pas de préférence.",
  }));
}

export async function getFeedbackForVersion(
  supabase: SupabaseClient,
  versionId: string
): Promise<Feedback | null> {
  const { data, error } = await supabase
    .from("feedback")
    .select("*")
    .eq("instruction_version_id", versionId)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as Feedback | null) ?? null;
}

// 👍 : enregistre uniquement le feedback. Aucune instruction ni version n'est modifiée.
export async function savePositiveFeedback(
  supabase: SupabaseClient,
  userId: string,
  versionId: string
): Promise<"saved" | "already" | "conflict"> {
  const { error } = await supabase.from("feedback").insert({
    instruction_version_id: versionId,
    user_id: userId,
    is_positive: true,
    comment: null,
    analysis: null,
  });
  if (!error) return "saved";
  if (!isUniqueViolation(error)) throw new Error(error.message);

  const existing = await getFeedbackForVersion(supabase, versionId);
  return existing?.is_positive ? "already" : "conflict";
}

export interface ImproveParams {
  projectId: string;
  category: CategoryId;
  idea: string;
  analysis: IntentAnalysis;
  answers: QuestionAnswer[];
  baseVersionNumber: number;
  feedback: string;
}

export type ImproveResult =
  | { status: "created"; current: CurrentInstruction }
  | { status: "conflict" };

// 👎 : analyse le retour, génère la version N+1 et la rend courante, en une seule transaction.
export async function createImprovedInstructionVersion(
  supabase: SupabaseClient,
  provider: AIProvider,
  params: ImproveParams
): Promise<ImproveResult> {
  // 1-3. Instruction, current_version et version actuelle.
  const current = await getCurrentInstruction(supabase, params.projectId);
  if (!current) throw new Error("Aucune instruction à améliorer.");

  // La version affichée doit être la version actuelle, et ne pas avoir déjà reçu de retour.
  if (current.version.version_number !== params.baseVersionNumber) {
    return { status: "conflict" };
  }
  if (await getFeedbackForVersion(supabase, current.version.id)) {
    return { status: "conflict" };
  }

  // 4. Prochaine version.
  const nextVersion = current.instruction.current_version + 1;

  // 5. Analyse du retour (aucune écriture en base à ce stade).
  const baseInput = {
    category: params.category,
    idea: params.idea,
    analysis: params.analysis,
    answers: params.answers,
    instruction: current.version.content,
    feedback: params.feedback,
  };
  const feedbackAnalysis = feedbackAnalysisSchema.parse(
    await provider.analyzeFeedback(baseInput)
  );

  // 6. Génération de la nouvelle instruction (aucune écriture en base non plus).
  const improved = builtInstructionSchema.parse(
    await provider.improveInstruction({ ...baseInput, feedbackAnalysis })
  );

  // 7-8. Feedback + version N+1 + current_version, de façon atomique (fonction SQL).
  //      Si quoi que ce soit échoue, rien n'est enregistré : pas de version fantôme.
  const { error } = await supabase.rpc("create_improved_version", {
    p_instruction_id: current.instruction.id,
    p_base_version: current.version.version_number,
    p_comment: params.feedback,
    p_analysis: feedbackAnalysis,
    p_content: improved.content,
    p_summary: improved.summary,
  });
  if (error) {
    if (isUniqueViolation(error) || error.message.includes("version_conflict")) {
      return { status: "conflict" };
    }
    throw new Error(error.message);
  }

  const updated = await getCurrentInstruction(supabase, params.projectId);
  if (!updated || updated.version.version_number !== nextVersion) {
    throw new Error("La nouvelle version est introuvable après création.");
  }
  return { status: "created", current: updated };
}

// Données prêtes pour une future page d'historique : toutes les versions, avec leur retour.
export interface VersionHistoryItem {
  versionNumber: number;
  content: string;
  changeSummary: string | null;
  createdAt: string;
  feedback: { isPositive: boolean; comment: string | null; createdAt: string } | null;
}

export async function getVersionHistory(
  supabase: SupabaseClient,
  instructionId: string
): Promise<VersionHistoryItem[]> {
  const { data: versionRows, error } = await supabase
    .from("instruction_versions")
    .select("*")
    .eq("instruction_id", instructionId)
    .order("version_number", { ascending: true });
  if (error) throw new Error(error.message);
  const versions = (versionRows ?? []) as InstructionVersion[];
  if (versions.length === 0) return [];

  const { data: feedbackRows, error: feedbackError } = await supabase
    .from("feedback")
    .select("*")
    .in("instruction_version_id", versions.map((version) => version.id));
  if (feedbackError) throw new Error(feedbackError.message);
  const feedbackByVersion = new Map(
    ((feedbackRows ?? []) as Feedback[]).map((item) => [item.instruction_version_id, item])
  );

  return versions.map((version) => {
    const item = feedbackByVersion.get(version.id);
    return {
      versionNumber: version.version_number,
      content: version.content,
      changeSummary: version.change_summary,
      createdAt: version.created_at,
      feedback: item
        ? { isPositive: item.is_positive, comment: item.comment, createdAt: item.created_at }
        : null,
    };
  });
}
