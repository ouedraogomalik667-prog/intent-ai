import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().trim().email("Adresse email invalide."),
  password: z.string().min(1, "Le mot de passe est obligatoire."),
});

export const signupSchema = z.object({
  displayName: z
    .string()
    .trim()
    .min(1, "Indique ton prénom.")
    .max(50, "Prénom trop long (50 caractères maximum)."),
  email: z.string().trim().email("Adresse email invalide."),
  password: z
    .string()
    .min(8, "Le mot de passe doit contenir au moins 8 caractères.")
    .max(72, "Le mot de passe est trop long (72 caractères maximum)."),
});
