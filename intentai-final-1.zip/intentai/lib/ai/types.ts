import type { z } from "zod";
import type { CategoryId } from "@/types";
import type {
  infoKeySchema,
  intentAnalysisSchema,
  missingInfoSchema,
  providedInfoSchema,
  questionSchema,
  storedIntentSchema,
} from "@/lib/ai/schemas";
import type { feedbackAnalysisSchema } from "@/lib/ai/feedback-schemas";

export type InfoKey = z.infer<typeof infoKeySchema>;
export type ProvidedInfo = z.infer<typeof providedInfoSchema>;
export type MissingInfo = z.infer<typeof missingInfoSchema>;
export type IntentAnalysis = z.infer<typeof intentAnalysisSchema>;
export type Question = z.infer<typeof questionSchema>;
export type StoredIntent = z.infer<typeof storedIntentSchema>;

// Analyse du retour : ce qui ne va pas, ce qu'on garde, ce qu'on corrige ou ajoute.
export type FeedbackAnalysis = z.infer<typeof feedbackAnalysisSchema>;

export interface AnalyzeIntentInput {
  idea: string;
  category: CategoryId;
}

export interface GenerateQuestionsInput {
  analysis: IntentAnalysis;
}

export interface QuestionAnswer {
  key: InfoKey;
  question: string;
  answer: string;
}

export interface BuildInstructionInput {
  idea: string;
  analysis: IntentAnalysis;
  answers: QuestionAnswer[];
}

export interface BuiltInstruction {
  content: string;
  summary: string;
}

export interface AnalyzeFeedbackInput {
  category: CategoryId;
  idea: string;
  analysis: IntentAnalysis;
  answers: QuestionAnswer[];
  instruction: string;
  feedback: string;
}

export interface ImproveInstructionInput extends AnalyzeFeedbackInput {
  feedbackAnalysis: FeedbackAnalysis;
}
