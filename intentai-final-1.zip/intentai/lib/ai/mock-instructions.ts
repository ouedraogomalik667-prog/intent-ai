import type { CategoryId } from "@/types";
import type { BuildInstructionInput, BuiltInstruction, InfoKey } from "@/lib/ai/types";

interface CategorySpec {
  role: string;
  include: string[];
  avoid: string[];
  closing: string;
}

const SPECS: Record<CategoryId, CategorySpec> = {
  video: {
    role: "un créateur de contenu et scénariste vidéo expérimenté, spécialisé dans les vidéos courtes qui retiennent l'attention",
    include: [
      "Une accroche forte dès les premières secondes",
      "Un script découpé en scènes (ce qu'on voit, ce qu'on dit, le texte à l'écran)",
      "Une idée de musique ou d'ambiance sonore",
      "Un appel à l'action clair à la fin",
    ],
    avoid: [
      "Les introductions longues et les phrases creuses",
      "Les promesses exagérées ou fausses",
      "Le jargon technique",
    ],
    closing:
      "Donne-moi directement le script complet, prêt à être tourné. Si une information essentielle te manque, pose-moi une seule question avant de commencer.",
  },
  image: {
    role: "un directeur artistique expert en création de visuels",
    include: [
      "La composition et le cadrage",
      "La palette de couleurs et l'éclairage",
      "L'ambiance générale du visuel",
      "Les éléments précis à représenter",
    ],
    avoid: [
      "Les détails inutiles qui surchargent l'image",
      "Les logos et marques tierces",
      "Un texte illisible ou déformé",
    ],
    closing:
      "Rédige le résultat sous forme d'une description prête à coller dans un générateur d'images, puis propose deux variantes.",
  },
  business: {
    role: "un consultant business pragmatique, habitué à accompagner de petits entrepreneurs",
    include: [
      "Un plan d'action en étapes concrètes",
      "Les priorités à traiter en premier",
      "Une estimation réaliste du budget et des ressources",
      "Des indicateurs simples pour mesurer les résultats",
    ],
    avoid: [
      "Les conseils généraux sans application concrète",
      "La théorie inutile",
      "Les hypothèses irréalistes",
    ],
    closing:
      "Termine par les trois actions à faire cette semaine. Si une information essentielle te manque, pose-moi une seule question avant de commencer.",
  },
  code: {
    role: "un développeur senior pédagogue",
    include: [
      "Un code complet et fonctionnel, sans pseudo-code",
      "Une explication simple de chaque partie",
      "Les étapes exactes pour l'installer et l'exécuter",
      "L'organisation des fichiers si le projet en compte plusieurs",
    ],
    avoid: [
      "Les dépendances inutiles",
      "Les explications trop techniques",
      "Les raccourcis qui compliquent la maintenance",
    ],
    closing:
      "Avance étape par étape et vérifie que chaque étape fonctionne avant de passer à la suivante.",
  },
  learn: {
    role: "un professeur patient et pédagogue",
    include: [
      "Des explications simples avec des exemples concrets",
      "Une progression par étapes, du plus simple au plus avancé",
      "Des exercices pratiques avec leur correction",
      "Un court résumé des points essentiels",
    ],
    avoid: ["Le jargon non expliqué", "Les longs passages théoriques", "Les sauts d'étapes"],
    closing:
      "Commence par la première étape, puis vérifie ma compréhension avec une petite question avant de continuer.",
  },
  write: {
    role: "un rédacteur professionnel",
    include: [
      "Une accroche qui donne envie de lire",
      "Une structure claire et facile à suivre",
      "Une conclusion ou un appel à l'action adapté",
    ],
    avoid: [
      "Les formules creuses et les répétitions",
      "Les phrases trop longues",
      "Les fautes d'orthographe et de grammaire",
    ],
    closing: "Rédige directement le texte final, prêt à être utilisé.",
  },
  research: {
    role: "un chercheur méthodique et rigoureux",
    include: [
      "Une synthèse claire des points essentiels",
      "Les différents points de vue lorsqu'il y en a",
      "La provenance des informations lorsque c'est possible",
      "Ce qui reste incertain ou discuté",
    ],
    avoid: [
      "Les affirmations non vérifiées",
      "Les sources inventées",
      "Les informations dépassées sans le signaler",
    ],
    closing: "Distingue clairement ce qui est établi de ce qui est incertain.",
  },
  other: {
    role: "un assistant polyvalent, précis et pédagogue",
    include: [
      "Une réponse claire et directement utilisable",
      "Des exemples concrets quand ils aident",
    ],
    avoid: ["Le jargon inutile", "Les réponses trop longues ou vagues"],
    closing:
      "Réponds directement avec le résultat. Si une information essentielle te manque, pose-moi une seule question avant de commencer.",
  },
};

const INFO_LINES: Array<{ key: InfoKey; label: string }> = [
  { key: "product", label: "Produit ou service" },
  { key: "place", label: "Lieu" },
  { key: "techStack", label: "Technologie" },
  { key: "level", label: "Niveau" },
  { key: "learningFormat", label: "Format d'apprentissage" },
  { key: "purpose", label: "But" },
];

const PRODUCT_CATEGORIES: CategoryId[] = ["video", "image", "write", "business"];
const UNKNOWN_TEXT = "à toi de choisir la meilleure option pour moi";

function isNoPreference(answer: string): boolean {
  return /^pas de préférence\.?$/i.test(answer.trim());
}

function isUnknown(answer: string): boolean {
  return /^je ne sais pas/i.test(answer.trim());
}

function capitalize(text: string): string {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function sentence(text: string): string {
  const trimmed = text.trim();
  return /[.!?…]$/.test(trimmed) ? trimmed : `${trimmed}.`;
}

function block(title: string, lines: string[]): string {
  return [title, ...lines].join("\n");
}

function bullets(items: string[]): string[] {
  return items.map((item) => `- ${item}`);
}

export function buildMockInstruction({
  idea,
  analysis,
  answers,
}: BuildInstructionInput): BuiltInstruction {
  const spec = SPECS[analysis.category];

  // Réponses réellement données (on ignore « Pas de préférence »).
  const given = new Map<InfoKey, string>();
  for (const item of answers) {
    if (isNoPreference(item.answer)) continue;
    given.set(item.key, isUnknown(item.answer) ? UNKNOWN_TEXT : item.answer.trim());
  }

  const provided = (key: InfoKey): string | null =>
    analysis.providedInformation.find((info) => info.key === key)?.value ?? null;
  const fact = (key: InfoKey): string | null => provided(key) ?? given.get(key) ?? null;

  const audience = analysis.audience ?? given.get("audience") ?? null;
  const style = analysis.style ?? given.get("style") ?? null;
  const format = analysis.format ?? given.get("platform") ?? given.get("textType") ?? null;

  const constraints = [...analysis.constraints];
  const length = given.get("length");
  if (length) constraints.push(`Durée / longueur : ${length}`);
  const budget = given.get("budget");
  if (budget) constraints.push(`Budget : ${budget}`);
  const language = given.get("language");
  if (language) constraints.push(`Langue : ${language}`);

  const include = [...spec.include];
  const avoid = [...spec.avoid];

  const product = fact("product");
  if (product && PRODUCT_CATEGORIES.includes(analysis.category)) {
    include.unshift(`Mettre en avant : ${product}`);
  }
  const callToAction = given.get("callToAction");
  if (callToAction) include.push(`Appel à l'action : ${callToAction}`);
  const textOnImage = given.get("textOnImage");
  if (textOnImage) {
    if (/^non\b/i.test(textOnImage)) {
      avoid.push("Tout texte écrit sur l'image");
    } else {
      include.push(`Texte à afficher sur l'image : ${textOnImage}`);
    }
  }

  const info: string[] = [];
  const goalDetail = given.get("goal");
  if (goalDetail) info.push(`Précision sur l'objectif : ${goalDetail}`);
  for (const { key, label } of INFO_LINES) {
    const value = fact(key);
    if (value) info.push(`${label} : ${value}`);
  }

  let closing = spec.closing;
  if (analysis.category === "code" && /d[ée]butant/i.test(fact("level") ?? "")) {
    closing += " Je suis débutant : explique chaque étape simplement.";
  }

  const answered = answers.filter((item) => !isNoPreference(item.answer));

  const sections: string[] = [
    block("RÔLE", [`Tu es ${spec.role}.`]),
    block("OBJECTIF", [sentence(analysis.objective)]),
    block("CONTEXTE", [sentence(analysis.context)]),
    block("PUBLIC CIBLE", [
      audience
        ? sentence(audience)
        : "Public non précisé : adopte un langage accessible à tout le monde.",
    ]),
    block("RÉSULTAT ATTENDU", [sentence(analysis.expectedResult)]),
  ];
  if (format) sections.push(block("FORMAT", [sentence(format)]));
  sections.push(
    block("STYLE ET TON", [
      style ? sentence(capitalize(style)) : "Clair, naturel et facile à comprendre.",
    ])
  );
  if (constraints.length > 0) sections.push(block("CONTRAINTES", bullets(constraints)));
  if (info.length > 0) sections.push(block("INFORMATIONS IMPORTANTES", bullets(info)));
  if (answered.length > 0) {
    sections.push(
      block(
        "RÉPONSES AUX QUESTIONS",
        bullets(answered.map((item) => `${item.question} → ${item.answer.trim()}`))
      )
    );
  }
  sections.push(block("À INCLURE", bullets(include)));
  sections.push(block("À ÉVITER", bullets(avoid)));
  sections.push(block("CONSIGNE FINALE", [closing]));
  sections.push(block("IDÉE D'ORIGINE", [`« ${idea.trim()} »`]));

  return {
    content: sections.join("\n\n"),
    summary: "Première version créée à partir de ton idée et de tes réponses.",
  };
}
