import type { CategoryId } from "@/types";
import type { AIProvider } from "@/lib/ai/provider";
import type {
  AnalyzeFeedbackInput,
  AnalyzeIntentInput,
  BuildInstructionInput,
  BuiltInstruction,
  FeedbackAnalysis,
  GenerateQuestionsInput,
  ImproveInstructionInput,
  InfoKey,
  IntentAnalysis,
  MissingInfo,
  ProvidedInfo,
  Question,
} from "@/lib/ai/types";
import { buildMockInstruction } from "@/lib/ai/mock-instructions";
import { analyzeMockFeedback, improveMockInstruction } from "@/lib/ai/mock-feedback";

const MAX_QUESTIONS = 3;

type Signals = Record<InfoKey, string | null>;

interface LabeledWords {
  words: string[];
  label: string;
}

interface RuleContext {
  norm: string;
  sells: boolean;
}

interface Rule {
  key: InfoKey;
  importance: MissingInfo["importance"];
  applies?: (context: RuleContext) => boolean;
}

/* ---------- Dictionnaires de détection ---------- */

const LABELS: Record<InfoKey, string> = {
  goal: "Objectif",
  platform: "Plateforme / support",
  place: "Lieu",
  product: "Produit",
  audience: "Public",
  style: "Style",
  length: "Durée / longueur",
  budget: "Budget",
  language: "Langue",
  textType: "Type de texte",
  callToAction: "Appel à l'action",
  textOnImage: "Texte à afficher",
  techStack: "Technologie",
  level: "Niveau",
  learningFormat: "Format d'apprentissage",
  purpose: "But",
};

const PLATFORMS: LabeledWords[] = [
  { words: ["tiktok", "tik tok"], label: "TikTok" },
  { words: ["instagram", "reels"], label: "Instagram" },
  { words: ["facebook"], label: "Facebook" },
  { words: ["youtube"], label: "YouTube" },
  { words: ["linkedin"], label: "LinkedIn" },
  { words: ["whatsapp"], label: "WhatsApp" },
  { words: ["snapchat"], label: "Snapchat" },
  { words: ["affiche"], label: "Affiche" },
  { words: ["flyer"], label: "Flyer" },
  { words: ["logo"], label: "Logo" },
  { words: ["site web", "page web", "landing"], label: "Site web" },
  { words: ["email", "e-mail", "mail", "newsletter"], label: "Email" },
];
const SOCIAL_PLATFORMS = ["TikTok", "Instagram", "Facebook", "YouTube", "LinkedIn", "WhatsApp", "Snapchat"];
const PRINT_FORMATS = ["Affiche", "Flyer", "Logo"];

const TEXT_TYPES: LabeledWords[] = [
  { words: ["email", "e-mail", "mail", "courriel"], label: "Email" },
  { words: ["article", "blog"], label: "Article de blog" },
  { words: ["post", "posts", "publication", "legende"], label: "Publication pour réseaux sociaux" },
  { words: ["lettre", "motivation"], label: "Lettre" },
  { words: ["discours"], label: "Discours" },
  { words: ["histoire", "conte", "nouvelle", "roman"], label: "Histoire" },
  { words: ["script", "scenario"], label: "Script" },
  { words: ["cv"], label: "CV" },
  { words: ["description", "fiche produit"], label: "Description" },
  { words: ["resume"], label: "Résumé" },
];

const TECH: LabeledWords[] = [
  { words: ["python"], label: "Python" },
  { words: ["javascript", "js"], label: "JavaScript" },
  { words: ["typescript"], label: "TypeScript" },
  { words: ["react", "nextjs", "next.js"], label: "React / Next.js" },
  { words: ["html", "css"], label: "HTML / CSS" },
  { words: ["php"], label: "PHP" },
  { words: ["java"], label: "Java" },
  { words: ["flutter"], label: "Flutter" },
  { words: ["wordpress"], label: "WordPress" },
  { words: ["excel"], label: "Excel" },
  { words: ["sql"], label: "SQL" },
  { words: ["swift", "kotlin"], label: "Application mobile native" },
];

const AUDIENCES: LabeledWords[] = [
  { words: ["etudiant", "eleve"], label: "Étudiants / élèves" },
  { words: ["enfant"], label: "Enfants" },
  { words: ["debutant"], label: "Débutants" },
  { words: ["parent"], label: "Parents" },
  { words: ["jeune", "adolescent"], label: "Jeunes" },
  { words: ["entrepreneur", "commercant"], label: "Entrepreneurs / commerçants" },
  { words: ["abonne", "follower"], label: "Abonnés" },
  { words: ["lecteur"], label: "Lecteurs" },
  { words: ["femme"], label: "Femmes" },
  { words: ["touriste"], label: "Touristes" },
  { words: ["collegue", "equipe", "employe"], label: "Équipe / collègues" },
  { words: ["client"], label: "Clients" },
];

const STYLES: LabeledWords[] = [
  { words: ["professionnel"], label: "professionnel" },
  { words: ["drole", "humour", "humoristique"], label: "humoristique" },
  { words: ["moderne"], label: "moderne" },
  { words: ["luxe", "premium", "elegant", "chic"], label: "élégant / premium" },
  { words: ["dynamique", "energique", "fun", "joyeux"], label: "dynamique" },
  { words: ["serieux", "formel"], label: "sérieux" },
  { words: ["chaleureux", "amical", "decontracte"], label: "chaleureux" },
  { words: ["minimaliste", "epure"], label: "minimaliste" },
  { words: ["simple", "clair"], label: "simple et clair" },
  { words: ["inspirant", "touchant", "emotion"], label: "inspirant" },
];

const LANGUAGES: LabeledWords[] = [
  { words: ["en francais"], label: "Français" },
  { words: ["en anglais"], label: "Anglais" },
  { words: ["en moore"], label: "Mooré" },
  { words: ["en dioula"], label: "Dioula" },
  { words: ["en espagnol"], label: "Espagnol" },
  { words: ["bilingue"], label: "Bilingue" },
];

const LEVELS: LabeledWords[] = [
  { words: ["debutant", "partir de zero", "novice"], label: "Débutant" },
  { words: ["intermediaire"], label: "Intermédiaire" },
  { words: ["avance", "expert"], label: "Avancé" },
];

const LEARNING_FORMATS: LabeledWords[] = [
  { words: ["exercice", "quiz"], label: "Exercices pratiques" },
  { words: ["fiche", "resume"], label: "Fiches de révision" },
  { words: ["video"], label: "Vidéos" },
  { words: ["plan", "programme", "planning"], label: "Plan d'apprentissage" },
];

const SELL_WORDS = [
  "vendre",
  "vente",
  "vendant",
  "promouvoir",
  "promotion",
  "publicite",
  "faire connaitre",
  "clients",
  "boutique",
];
const CTA_WORDS = [
  "contacter",
  "commander",
  "acheter",
  "whatsapp",
  "appeler",
  "lien en bio",
  "inscrire",
  "reserver",
  "telecharger",
  "visiter",
];
const TEXT_ON_IMAGE_WORDS = ["slogan", "titre", "avec le texte", "ecrit", "phrase", "prix"];
const VISUAL_WORDS = ["affiche", "flyer", "visuel", "banniere", "carte", "publicite", "pub", "couverture"];

const BRAND_WORDS = [
  "tiktok",
  "instagram",
  "facebook",
  "youtube",
  "linkedin",
  "whatsapp",
  "snapchat",
  "python",
  "javascript",
  "typescript",
  "react",
  "html",
  "css",
  "php",
  "java",
  "excel",
  "word",
  "wordpress",
  "flutter",
  "canva",
  "chatgpt",
  "gemini",
  "claude",
];

const CATEGORY_CONTEXT: Record<CategoryId, string> = {
  learn: "Apprentissage d'un sujet",
  write: "Rédaction d'un texte",
  image: "Création d'un visuel",
  video: "Création de contenu vidéo",
  business: "Projet business",
  code: "Projet de programmation",
  research: "Recherche d'informations",
  other: "Demande générale",
};

/* ---------- Règles : ce qu'il faut savoir selon la catégorie ---------- */

const RULES: Record<CategoryId, Rule[]> = {
  video: [
    { key: "goal", importance: "critical" },
    { key: "platform", importance: "critical" },
    { key: "audience", importance: "important" },
    { key: "callToAction", importance: "important", applies: (c) => c.sells },
    { key: "style", importance: "important" },
    { key: "length", importance: "important" },
    { key: "language", importance: "optional" },
  ],
  image: [
    { key: "goal", importance: "critical" },
    { key: "platform", importance: "critical" },
    {
      key: "textOnImage",
      importance: "important",
      applies: (c) => c.sells || hasAny(c.norm, VISUAL_WORDS),
    },
    { key: "style", importance: "important" },
    { key: "audience", importance: "optional" },
  ],
  write: [
    { key: "goal", importance: "critical" },
    { key: "textType", importance: "critical" },
    { key: "audience", importance: "important" },
    { key: "style", importance: "important" },
    { key: "length", importance: "important" },
    { key: "language", importance: "optional" },
  ],
  business: [
    { key: "goal", importance: "critical" },
    { key: "audience", importance: "critical" },
    { key: "place", importance: "important" },
    { key: "budget", importance: "important" },
  ],
  code: [
    { key: "goal", importance: "critical" },
    { key: "techStack", importance: "critical" },
    { key: "level", importance: "important" },
  ],
  learn: [
    { key: "goal", importance: "critical" },
    { key: "level", importance: "critical" },
    { key: "learningFormat", importance: "important" },
    { key: "length", importance: "important" },
  ],
  research: [
    { key: "goal", importance: "critical" },
    { key: "purpose", importance: "critical" },
    { key: "length", importance: "important" },
  ],
  other: [
    { key: "goal", importance: "critical" },
    { key: "purpose", importance: "important" },
    { key: "audience", importance: "important" },
  ],
};

/* ---------- Fonctions utilitaires ---------- */

function normalize(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function hasAny(norm: string, words: string[]): boolean {
  return words.some((word) => {
    if (word.length >= 5) return norm.includes(word);
    return new RegExp(`(^|[^a-z0-9])${word}([^a-z0-9]|$)`).test(norm);
  });
}

function capitalize(text: string): string {
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function detectLabel(norm: string, entries: LabeledWords[]): string | null {
  const found = entries.find((entry) => hasAny(norm, entry.words));
  return found ? found.label : null;
}

function detectAllLabels(norm: string, entries: LabeledWords[]): string | null {
  const labels = entries.filter((e) => hasAny(norm, e.words)).map((e) => e.label);
  return labels.length > 0 ? labels.join(", ") : null;
}

function extractPlace(idea: string): string | null {
  const regex =
    /(?:^|\s)(?:à|au|en|dans)\s+([A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]*(?:\s+[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’-]*)*)/g;
  for (const match of idea.matchAll(regex)) {
    const candidate = match[1]?.trim();
    if (candidate && !BRAND_WORDS.includes(normalize(candidate))) {
      return candidate;
    }
  }
  return null;
}

function extractProduct(idea: string): string | null {
  const regex =
    /(?:vendre|vendant|vente\s+d[e'’]\s*|promouvoir|faire\s+connaître|présenter|lancer)\s*((?:(?:mes|mon|ma|nos|notre|des|du|de\s+la|les|le|la|un|une)\s+|l['’])?[^.,;!?]+?)(?=\s+(?:à|au|aux|en|dans|sur|pour|avec|via|grâce)\s|[.,;!?]|$)/i;
  const value = idea.match(regex)?.[1]?.trim();
  return value && value.length >= 3 ? value : null;
}

function extractPurpose(idea: string): string | null {
  const regex = /(?:pour|afin\s+de|afin\s+d['’])\s*([a-zà-ÿ]+(?:er|ir|re)\s[^.,;!?]{3,60})/i;
  return idea.match(regex)?.[1]?.trim() ?? null;
}

function extractLength(norm: string): string | null {
  const measured = norm.match(
    /(\d+)\s*(secondes?|sec|minutes?|min|mots?|pages?|lignes?|caracteres?|slides?|diapos?|heures?|jours?|semaines?)(?![a-z])/
  );
  if (measured) return measured[0].trim();
  if (hasAny(norm, ["court", "courte", "bref", "concis"])) return "Court";
  if (hasAny(norm, ["detaille", "approfondi"])) return "Détaillé";
  return null;
}

function extractBudget(idea: string, norm: string): string | null {
  const amount = idea.match(
    /(\d[\d\s.,]*\s*(?:fcfa|f\s?cfa|xof|cfa|€|eur(?:os?)?|\$|usd|dollars?))/i
  );
  if (amount?.[1]) return amount[1].trim();
  if (hasAny(norm, ["gratuit", "sans budget", "petit budget", "pas de budget"])) {
    return "Budget très limité";
  }
  return null;
}

function buildObjective(idea: string, sells: boolean, product: string | null): string {
  if (sells && product) return `Vendre ${product}`;
  const cleaned = idea
    .trim()
    .replace(
      /^(?:bonjour[, ]*)?(?:je\s+(?:veux|voudrais|souhaite|cherche\s+à|dois|peux)|j['’](?:aimerais|ai\s+besoin\s+d['’e]?)|peux-tu|pouvez-vous|pourrais-tu)\s*/i,
      ""
    );
  const sentence = cleaned.split(/[.!?\n]/)[0]?.trim() ?? "";
  const base = sentence.length > 0 ? sentence : idea.trim();
  return capitalize(base.length > 160 ? `${base.slice(0, 157)}...` : base);
}

function buildContext(signals: Signals, category: CategoryId, sells: boolean): string {
  const parts: string[] = [];
  if (sells) {
    parts.push(signals.place ? `Activité commerciale à ${signals.place}` : "Activité commerciale");
  } else if (signals.place) {
    parts.push(`Lieu concerné : ${signals.place}`);
  }
  if (signals.product) parts.push(`produit : ${signals.product}`);
  return parts.length > 0 ? parts.join(" ; ") : CATEGORY_CONTEXT[category];
}

function buildExpectedResult(category: CategoryId, signals: Signals): string {
  switch (category) {
    case "video":
      return `Un contenu vidéo${signals.platform ? ` pour ${signals.platform}` : ""} prêt à tourner : idée, script et scènes`;
    case "image":
      return "Une description d'image précise, prête à être utilisée dans un générateur d'images";
    case "write":
      return `${signals.textType ?? "Un texte"} prêt à être utilisé`;
    case "business":
      return "Un plan d'action concret et réaliste";
    case "code":
      return `Un code fonctionnel${signals.techStack ? ` en ${signals.techStack}` : ""}, expliqué pas à pas`;
    case "learn":
      return "Une explication claire et progressive, adaptée à ton niveau";
    case "research":
      return "Une synthèse structurée et fiable, avec les points clés";
    case "other":
      return "Un résultat clair et directement utilisable";
  }
}

function buildFormat(category: CategoryId, signals: Signals): string | null {
  const { platform } = signals;
  if (category === "video" && platform) {
    return SOCIAL_PLATFORMS.includes(platform) ? `Vidéo ${platform}` : `Vidéo pour ${platform}`;
  }
  if (category === "image" && platform) {
    return PRINT_FORMATS.includes(platform) ? platform : `Visuel pour ${platform}`;
  }
  if (category === "write" && signals.textType) return signals.textType;
  if (category === "code" && signals.techStack) return signals.techStack;
  return platform;
}

function ask(
  id: InfoKey,
  text: string,
  suggestions: string[] = [],
  hint: string | null = null
): Question {
  return { id, text, hint, suggestions };
}

function buildQuestion(key: InfoKey, analysis: IntentAnalysis): Question {
  const category = analysis.category;
  switch (key) {
    case "goal":
      return ask(key, "En une phrase, que veux-tu obtenir exactement ?", [], "Décris le résultat final que tu imagines.");
    case "platform":
      if (category === "video") {
        return ask(key, "Sur quelle plateforme veux-tu publier cette vidéo ?", ["TikTok", "Instagram Reels", "YouTube Shorts", "Facebook"]);
      }
      if (category === "image") {
        return ask(key, "Où vas-tu utiliser cette image ?", ["Réseaux sociaux", "Impression (affiche, flyer)", "Site web", "WhatsApp"]);
      }
      return ask(key, "Sur quel support veux-tu l'utiliser ?", ["Réseaux sociaux", "Site web", "Document", "Impression"]);
    case "place":
      return ask(key, "Dans quel lieu ou quelle ville cela se passe-t-il ?");
    case "product":
      return ask(key, "Quel produit ou service veux-tu mettre en avant ?");
    case "audience":
      if (category === "business") {
        return ask(key, "Qui sont tes clients idéaux ?", ["Particuliers", "Entreprises", "Étudiants", "Jeunes (18-30 ans)"], "Âge, métier, centres d'intérêt… dis-le simplement.");
      }
      if (category === "write") {
        return ask(key, "Pour qui écris-tu ce texte ?", ["Mes clients", "Mes abonnés", "Mon patron", "Un ami"]);
      }
      return ask(key, "Qui veux-tu toucher avec cela ?", ["Grand public", "Jeunes", "Professionnels", "Débutants"], "Âge, métier, centres d'intérêt… dis-le simplement.");
    case "callToAction":
      return ask(key, "Que doit faire la personne après avoir vu le contenu ?", ["M'écrire sur WhatsApp", "Commander en ligne", "Venir en boutique", "Me suivre"]);
    case "style":
      if (category === "image") {
        return ask(key, "Quel style visuel imagines-tu ?", ["Moderne et minimaliste", "Coloré et dynamique", "Élégant / luxe", "Réaliste"]);
      }
      if (category === "write") {
        return ask(key, "Quel ton veux-tu ?", ["Professionnel", "Amical", "Humoristique", "Inspirant"]);
      }
      return ask(key, "Quelle ambiance veux-tu ?", ["Dynamique et fun", "Professionnelle", "Élégante / premium", "Humoristique"]);
    case "length":
      if (category === "video") {
        return ask(key, "Combien de temps doit durer la vidéo ?", ["15 secondes", "30 secondes", "60 secondes"]);
      }
      if (category === "learn") {
        return ask(key, "Combien de temps peux-tu y consacrer ?", ["15 minutes par jour", "1 heure par semaine", "Un week-end"]);
      }
      if (category === "research") {
        return ask(key, "Quelle profondeur veux-tu ?", ["Résumé rapide", "Analyse détaillée"]);
      }
      return ask(key, "Quelle longueur souhaites-tu ?", ["Court (quelques lignes)", "Moyen (1 page)", "Long et détaillé"]);
    case "budget":
      return ask(key, "Quel budget peux-tu y consacrer ?", ["Aucun", "Petit budget", "Budget moyen"]);
    case "language":
      return ask(key, "Dans quelle langue ?", ["Français", "Anglais", "Les deux"]);
    case "textType":
      return ask(key, "Quel type de texte veux-tu écrire ?", ["Email", "Publication réseaux sociaux", "Article", "Histoire"]);
    case "textOnImage":
      return ask(key, "Y a-t-il un texte à écrire sur l'image (titre, prix, slogan) ?", ["Non, aucun texte", "Oui : titre + prix", "Oui : un slogan"]);
    case "techStack":
      return ask(key, "Avec quel langage ou quelle technologie veux-tu le faire ?", ["Python", "JavaScript / React", "HTML + CSS", "Je ne sais pas"], "Si tu ne sais pas, réponds « Je ne sais pas » : IntentAI choisira le plus simple.");
    case "level":
      if (category === "code") {
        return ask(key, "Quel est ton niveau en programmation ?", ["Débutant", "Intermédiaire", "Avancé"]);
      }
      return ask(key, "Quel est ton niveau actuel sur ce sujet ?", ["Débutant complet", "J'ai des bases", "Intermédiaire"]);
    case "learningFormat":
      return ask(key, "Comment préfères-tu apprendre ?", ["Explications simples", "Exercices pratiques", "Plan étape par étape", "Fiches de révision"]);
    case "purpose":
      if (category === "research") {
        return ask(key, "À quoi va te servir cette recherche ?", ["Un exposé ou un devoir", "Une décision business", "Ma curiosité", "Un article"]);
      }
      return ask(key, "Pourquoi veux-tu faire cela ?");
  }
}

/* ---------- Le provider ---------- */

export class MockAIProvider implements AIProvider {
  readonly name = "mock";

  async analyzeIntent({ idea, category }: AnalyzeIntentInput): Promise<IntentAnalysis> {
    const norm = normalize(idea);
    const sells = hasAny(norm, SELL_WORDS);
    const product = extractProduct(idea);
    const techStack = detectLabel(norm, TECH);
    const objective = buildObjective(idea, sells, product);
    const wordCount = idea.trim().split(/\s+/).filter(Boolean).length;

    const signals: Signals = {
      goal: wordCount >= 5 || product !== null || techStack !== null ? objective : null,
      platform: detectLabel(norm, PLATFORMS),
      place: extractPlace(idea),
      product,
      audience: detectLabel(norm, AUDIENCES),
      style: detectAllLabels(norm, STYLES),
      length: extractLength(norm),
      budget: extractBudget(idea, norm),
      language: detectLabel(norm, LANGUAGES),
      textType: detectLabel(norm, TEXT_TYPES),
      callToAction: hasAny(norm, CTA_WORDS) ? "Appel à l'action indiqué" : null,
      textOnImage: hasAny(norm, TEXT_ON_IMAGE_WORDS) ? "Texte à afficher indiqué" : null,
      techStack,
      level: category === "learn" || category === "code" ? detectLabel(norm, LEVELS) : null,
      learningFormat: category === "learn" ? detectLabel(norm, LEARNING_FORMATS) : null,
      purpose: extractPurpose(idea),
    };

    const providedInformation: ProvidedInfo[] = [];
    for (const key of Object.keys(LABELS) as InfoKey[]) {
      const value = signals[key];
      if (value) providedInformation.push({ key, label: LABELS[key], value });
    }

    const ruleContext: RuleContext = { norm, sells };
    const missingInformation: MissingInfo[] = RULES[category]
      .filter((rule) => (rule.applies ? rule.applies(ruleContext) : true))
      .filter((rule) => signals[rule.key] === null)
      .map((rule) => ({
        key: rule.key,
        label: LABELS[rule.key],
        importance: rule.importance,
      }));

    const constraints: string[] = [];
    if (signals.length) constraints.push(`Durée / longueur : ${signals.length}`);
    if (signals.budget) constraints.push(`Budget : ${signals.budget}`);
    if (signals.language) constraints.push(`Langue : ${signals.language}`);

    const criticalMissing = missingInformation.filter((m) => m.importance === "critical").length;
    const rawConfidence = 0.45 + 0.08 * providedInformation.length - 0.12 * criticalMissing;
    const confidence = Math.round(Math.min(0.95, Math.max(0.2, rawConfidence)) * 100) / 100;

    return {
      objective,
      context: buildContext(signals, category, sells),
      audience: signals.audience,
      expectedResult: buildExpectedResult(category, signals),
      format: buildFormat(category, signals),
      style: signals.style,
      constraints,
      providedInformation,
      missingInformation,
      category,
      confidence,
    };
  }

  async generateQuestions({ analysis }: GenerateQuestionsInput): Promise<Question[]> {
    const known = new Set<InfoKey>(analysis.providedInformation.map((info) => info.key));
    const rank = { critical: 0, important: 1, optional: 2 } as const;

    return analysis.missingInformation
      .filter((missing) => missing.importance !== "optional" && !known.has(missing.key))
      .sort((a, b) => rank[a.importance] - rank[b.importance])
      .map((missing) => buildQuestion(missing.key, analysis))
      .slice(0, MAX_QUESTIONS);
  }

  async buildInstruction(input: BuildInstructionInput): Promise<BuiltInstruction> {
    return buildMockInstruction(input);
  }

  async analyzeFeedback(input: AnalyzeFeedbackInput): Promise<FeedbackAnalysis> {
    return analyzeMockFeedback(input);
  }

  async improveInstruction(input: ImproveInstructionInput): Promise<BuiltInstruction> {
    return improveMockInstruction(input);
  }
}
