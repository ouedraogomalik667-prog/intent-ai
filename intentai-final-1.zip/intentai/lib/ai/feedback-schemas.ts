import { z } from "zod";

export const feedbackAnalysisSchema = z.object({
  problems: z.array(z.string()),
  keep: z.array(z.string()),
  corrections: z.array(z.string()),
  additions: z.array(z.string()),
  priorities: z.array(z.string()),
});

export const builtInstructionSchema = z.object({
  content: z.string().min(1).max(20000),
  summary: z.string().min(1).max(500),
});
