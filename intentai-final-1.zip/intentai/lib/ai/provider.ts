import type {
  AnalyzeFeedbackInput,
  AnalyzeIntentInput,
  BuildInstructionInput,
  BuiltInstruction,
  FeedbackAnalysis,
  GenerateQuestionsInput,
  ImproveInstructionInput,
  IntentAnalysis,
  Question,
} from "@/lib/ai/types";

export interface AIProvider {
  readonly name: string;
  analyzeIntent(input: AnalyzeIntentInput): Promise<IntentAnalysis>;
  generateQuestions(input: GenerateQuestionsInput): Promise<Question[]>;
  buildInstruction(input: BuildInstructionInput): Promise<BuiltInstruction>;
  analyzeFeedback(input: AnalyzeFeedbackInput): Promise<FeedbackAnalysis>;
  improveInstruction(input: ImproveInstructionInput): Promise<BuiltInstruction>;
}

export class AIProviderError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "AIProviderError";
  }
}
