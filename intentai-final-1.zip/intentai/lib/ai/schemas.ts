import { z } from "zod";

export const CATEGORY_IDS = [
  "learn",
  "write",
  "image",
  "video",
  "business",
  "code",
  "research",
  "other",
] as const;
export const categoryIdSchema = z.enum(CATEGORY_IDS);

export const INFO_KEYS = [
  "goal",
  "platform",
  "place",
  "product",
  "audience",
  "style",
  "length",
  "budget",
  "language",
  "textType",
  "callToAction",
  "textOnImage",
  "techStack",
  "level",
  "learningFormat",
  "purpose",
] as const;
export const infoKeySchema = z.enum(INFO_KEYS);

export const providedInfoSchema = z.object({
  key: infoKeySchema,
  label: z.string(),
  value: z.string(),
});

export const missingInfoSchema = z.object({
  key: infoKeySchema,
  label: z.string(),
  importance: z.enum(["critical", "important", "optional"]),
});

export const intentAnalysisSchema = z.object({
  objective: z.string(),
  context: z.string(),
  audience: z.string().nullable(),
  expectedResult: z.string(),
  format: z.string().nullable(),
  style: z.string().nullable(),
  constraints: z.array(z.string()),
  providedInformation: z.array(providedInfoSchema),
  missingInformation: z.array(missingInfoSchema),
  category: categoryIdSchema,
  confidence: z.number().min(0).max(1),
});

export const questionSchema = z.object({
  id: infoKeySchema,
  text: z.string().min(1).max(300),
  hint: z.string().nullable(),
  suggestions: z.array(z.string()).max(6),
});

export const storedIntentSchema = z.object({
  analysis: intentAnalysisSchema,
  questions: z.array(questionSchema).max(3).nullable(),
});
