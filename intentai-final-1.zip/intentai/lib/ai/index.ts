import { getAiProviderName } from "@/lib/env";
import { MockAIProvider } from "@/lib/ai/mock";
import { AIProviderError, type AIProvider } from "@/lib/ai/provider";

let cached: AIProvider | null = null;

export function getAIProvider(): AIProvider {
  if (cached) return cached;

  const name = getAiProviderName();
  switch (name) {
    case "mock":
      cached = new MockAIProvider();
      return cached;
    default:
      throw new AIProviderError(
        `AI_PROVIDER="${name}" n'est pas encore disponible. Utilise AI_PROVIDER=mock dans .env.local.`
      );
  }
}

export type { AIProvider } from "@/lib/ai/provider";
