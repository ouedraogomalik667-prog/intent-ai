import type {
  AnalyzeFeedbackInput,
  BuiltInstruction,
  FeedbackAnalysis,
  ImproveInstructionInput,
} from "@/lib/ai/types";

// Fournisseur de test DÉTERMINISTE : des règles sur des mots-clés, pas une vraie IA.
// Même entrée = même sortie, ce qui rend les tests reproductibles.

function normalize(text: string): string {
  return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function hasAny(norm: string, words: string[]): boolean {
  return words.some((word) =>
    word.length >= 5
      ? norm.includes(word)
      : new RegExp(`(^|[^a-z0-9])${word}([^a-z0-9]|$)`).test(norm)
  );
}

const capitalize = (text: string): string => text.charAt(0).toUpperCase() + text.slice(1);
const isNoPreference = (answer: string): boolean => /^pas de préférence\.?$/i.test(answer.trim());

function shorten(text: string, max: number): string {
  const clean = text.trim().replace(/\s+/g, " ");
  return clean.length > max ? `${clean.slice(0, max - 1)}…` : clean;
}

/* ---------- Détection des problèmes ---------- */

type IssueId =
  | "tone-simple" | "tone-pro" | "tone-humor" | "tone-dynamic"
  | "shorter" | "longer" | "audience" | "missing" | "generic";

interface Issue {
  id: IssueId;
  problem: string;
  correction: string | null;
  addition: string | null;
  detail: string | null;
}

const issue = (
  id: IssueId,
  problem: string,
  correction: string | null,
  addition: string | null = null,
  detail: string | null = null
): Issue => ({ id, problem, correction, addition, detail });

const TONE_RULES = [
  {
    id: "tone-simple" as const,
    words: ["trop professionnel", "trop formel", "trop serieux", "trop technique", "trop complique", "jargon", "plus simple", "plus naturel", "plus decontracte", "plus amical", "plus chaleureux"],
    problem: "Le ton est trop professionnel ou trop technique",
    correction: "Adopter un ton plus simple, naturel et chaleureux",
    style: "Simple, naturel et chaleureux : phrases courtes, mots de tous les jours, aucun jargon.",
    action: "ton rendu plus simple et plus naturel",
  },
  {
    id: "tone-pro" as const,
    words: ["plus professionnel", "plus serieux", "plus formel", "pas assez professionnel", "trop familier"],
    problem: "Le ton n'est pas assez professionnel",
    correction: "Adopter un ton plus professionnel et crédible",
    style: "Professionnel et soigné : vocabulaire précis, ton posé et crédible.",
    action: "ton rendu plus professionnel",
  },
  {
    id: "tone-humor" as const,
    words: ["plus drole", "humour", "humoristique", "plus fun", "plus leger"],
    problem: "Le ton manque de légèreté",
    correction: "Ajouter une touche d'humour sans perdre le message",
    style: "Léger et humoristique : une touche d'humour sans perdre le message.",
    action: "ton rendu plus léger et humoristique",
  },
  {
    id: "tone-dynamic" as const,
    words: ["plus dynamique", "plus energique", "plus rythme", "trop mou", "trop plat"],
    problem: "Le ton manque de dynamisme",
    correction: "Adopter un ton plus dynamique et énergique",
    style: "Dynamique et énergique : phrases courtes et rythmées.",
    action: "ton rendu plus dynamique",
  },
];

const SHORTER = ["trop long", "trop detaille", "trop de details", "plus court", "plus concis", "raccourcir", "condenser", "alleger", "trop de texte", "trop lourd"];
const LONGER = ["trop court", "plus detaille", "plus de details", "developper", "approfondir", "plus complet", "trop vague", "trop leger", "trop succinct"];
const MISSING = ["il manque", "manque", "ajoute", "ajouter", "rajoute", "rajouter", "oublie", "inclure", "mentionne", "mentionner", "precise", "preciser"];
const AUDIENCE = ["public", "cible", "audience", "destinataire", "lecteur"];

const AUDIENCES: Array<{ words: string[]; label: string }> = [
  { words: ["etudiant", "eleve"], label: "Étudiants / élèves" },
  { words: ["enfant"], label: "Enfants" },
  { words: ["debutant"], label: "Débutants" },
  { words: ["parent"], label: "Parents" },
  { words: ["jeune", "adolescent"], label: "Jeunes" },
  { words: ["entrepreneur", "commercant"], label: "Entrepreneurs / commerçants" },
  { words: ["client"], label: "Clients" },
  { words: ["professionnel"], label: "Professionnels" },
];

function detectIssues(feedback: string): Issue[] {
  const norm = normalize(feedback);
  const issues: Issue[] = [];

  const tone = TONE_RULES.find((rule) => hasAny(norm, rule.words));
  if (tone) issues.push(issue(tone.id, tone.problem, tone.correction));

  if (hasAny(norm, SHORTER)) {
    issues.push(issue("shorter", "L'instruction est trop longue", "Réduire l'instruction à l'essentiel"));
  } else if (hasAny(norm, LONGER)) {
    issues.push(issue("longer", "L'instruction n'est pas assez détaillée", "Renforcer le niveau de détail"));
  }

  if (hasAny(norm, AUDIENCE)) {
    const label = AUDIENCES.find((entry) => hasAny(norm, entry.words))?.label ?? null;
    issues.push(
      label
        ? issue("audience", `Le public cible n'est pas bien pris en compte (${label})`, `Adapter l'instruction au public : ${label}`, `Public cible : ${label}`, label)
        : issue("audience", "Le public cible manque ou ne correspond pas", "Adapter l'instruction au public décrit par l'utilisateur")
    );
  } else if (hasAny(norm, MISSING)) {
    // On ne garde que les phrases qui expriment le manque.
    const parts = feedback
      .split(/[.!?\n]+/)
      .map((part) => part.trim())
      .filter((part) => part && hasAny(normalize(part), MISSING));
    issues.push(
      issue("missing", "Des informations importantes manquent", null, `Intégrer : ${shorten(parts.join(". ") || feedback, 200)}`)
    );
  }

  if (issues.length === 0) {
    const text = shorten(feedback, 200);
    issues.push(issue("generic", `Retour de l'utilisateur : ${text}`, `Tenir compte de ce retour : ${text}`));
  }
  return issues;
}

/* ---------- Sections de l'instruction ---------- */

interface Section {
  title: string;
  lines: string[];
}

const TITLE_REGEX = /^[A-ZÀ-ÖØ-Þ][A-ZÀ-ÖØ-Þ' ]*$/;

function parseSections(content: string): Section[] {
  const sections: Section[] = [];
  for (const block of content.trim().split(/\n{2,}/)) {
    const lines = block.split("\n");
    const first = (lines[0] ?? "").trim();
    if (TITLE_REGEX.test(first)) sections.push({ title: first, lines: lines.slice(1) });
    else if (sections.length > 0) sections[sections.length - 1].lines.push("", ...lines);
    else sections.push({ title: "INSTRUCTION", lines });
  }
  return sections;
}

const renderSections = (sections: Section[]): string =>
  sections.map((s) => [s.title, ...s.lines].join("\n")).join("\n\n");

function insertSection(sections: Section[], section: Section): void {
  const at = sections.findIndex((s) => s.title === "CONSIGNE FINALE");
  if (at >= 0) sections.splice(at, 0, section);
  else sections.push(section);
}

function setSection(sections: Section[], title: string, lines: string[]): void {
  const index = sections.findIndex((s) => s.title === title);
  if (index >= 0) sections[index] = { title, lines };
  else insertSection(sections, { title, lines });
}

function addBullets(sections: Section[], title: string, bullets: string[]): void {
  const index = sections.findIndex((s) => s.title === title);
  if (index < 0) {
    insertSection(sections, { title, lines: bullets.map((b) => `- ${b}`) });
    return;
  }
  for (const bullet of bullets) {
    if (!sections[index].lines.includes(`- ${bullet}`)) sections[index].lines.push(`- ${bullet}`);
  }
}

// Version concise : l'idée d'origine et le détail des réponses sont déjà intégrés ailleurs ;
// on garde les éléments propres à l'utilisateur (« ... : ... ») et 2 éléments génériques.
function makeConcise(sections: Section[]): Section[] {
  return sections
    .filter((s) => s.title !== "IDÉE D'ORIGINE" && s.title !== "RÉPONSES AUX QUESTIONS")
    .map((section) => {
      if (section.title !== "À INCLURE") return section;
      let generic = 0;
      const lines = section.lines.filter((line) => line.includes(" : ") || ++generic <= 2);
      return { ...section, lines };
    });
}

/* ---------- analyzeFeedback ---------- */

export function analyzeMockFeedback(input: AnalyzeFeedbackInput): FeedbackAnalysis {
  const issues = detectIssues(input.feedback);
  const ids = issues.map((i) => i.id);
  const hasTone = ids.some((id) => id.startsWith("tone-"));
  const hasLength = ids.includes("shorter") || ids.includes("longer");
  const hasAudience = ids.includes("audience");

  const sections = parseSections(input.instruction);
  const currentStyle = sections.find((s) => s.title === "STYLE ET TON")?.lines.join(" ").trim() ?? null;
  const given = input.answers.filter((a) => !isNoPreference(a.answer));
  const knownAudience = input.analysis.audience ?? given.find((a) => a.key === "audience")?.answer ?? null;

  const problems = issues.map((i) => {
    if (i.id === "audience" && knownAudience) {
      return `Le public actuel (${knownAudience}) ne convient pas ou doit être revu`;
    }
    if (i.id === "shorter") return `${i.problem} (${input.instruction.trim().length} caractères)`;
    return i.problem;
  });

  const keep = [`L'objectif : ${input.analysis.objective}`, `Le contexte : ${input.analysis.context}`];
  const facts = input.analysis.providedInformation
    .filter((info) => ["product", "place", "platform", "techStack"].includes(info.key))
    .map((info) => `${info.label} : ${info.value}`);
  if (facts.length > 0) keep.push(`Les informations fournies (${facts.join(" ; ")})`);
  if (given.length > 0) keep.push(`Les ${given.length} réponse(s) données aux questions`);
  if (!hasTone) {
    keep.push(currentStyle ? `Le ton actuel (${shorten(currentStyle, 60)})` : "Le ton et le style actuels");
  }
  if (!hasLength) keep.push("Le niveau de détail actuel");
  if (!hasAudience && knownAudience) keep.push(`Le public cible (${knownAudience})`);
  keep.push(`La structure en ${sections.length} sections`);

  const corrections = issues.flatMap((i) => (i.correction ? [i.correction] : []));
  const additions = issues.flatMap((i) => (i.addition ? [i.addition] : []));
  return { problems, keep, corrections, additions, priorities: [...corrections, ...additions].slice(0, 3) };
}

/* ---------- improveInstruction ---------- */

export function improveMockInstruction(input: ImproveInstructionInput): BuiltInstruction {
  const before = input.instruction.trim();
  let sections = parseSections(before);
  const actions: string[] = [];
  const adjustments: string[] = [];

  for (const found of detectIssues(input.feedback)) {
    switch (found.id) {
      case "tone-simple":
      case "tone-pro":
      case "tone-humor":
      case "tone-dynamic": {
        const rule = TONE_RULES.find((r) => r.id === found.id);
        if (rule) {
          setSection(sections, "STYLE ET TON", [rule.style]);
          actions.push(rule.action);
        }
        break;
      }
      case "shorter":
        sections = makeConcise(sections);
        addBullets(sections, "CONTRAINTES", ["Réponse courte : va à l'essentiel, sans introduction ni conclusion inutiles"]);
        actions.push("instruction raccourcie (éléments non essentiels retirés)");
        break;
      case "longer":
        addBullets(sections, "À INCLURE", [
          "Des exemples concrets et des explications détaillées pour chaque point",
          "Des étapes précises, sans rien sous-entendre",
        ]);
        addBullets(sections, "CONTRAINTES", ["Réponse détaillée et complète : développe chaque point"]);
        actions.push("niveau de détail renforcé");
        break;
      case "audience":
        setSection(sections, "PUBLIC CIBLE", [
          found.detail ? `${found.detail}.` : `Public décrit par l'utilisateur : « ${shorten(input.feedback, 200)} ».`,
        ]);
        actions.push(found.detail ? `public cible précisé : ${found.detail}` : "public cible précisé d'après ton retour");
        break;
      case "missing":
        if (found.addition) adjustments.push(found.addition);
        actions.push("information manquante intégrée");
        break;
      case "generic":
        if (found.correction) adjustments.push(found.correction);
        actions.push("retour pris en compte");
        break;
    }
  }

  if (adjustments.length > 0) addBullets(sections, "AJUSTEMENTS DEMANDÉS", adjustments);

  // Garantit une vraie nouvelle version : si rien n'a changé, on trace le retour.
  if (renderSections(sections) === before) {
    addBullets(sections, "AJUSTEMENTS DEMANDÉS", [
      `Retour sur la version précédente : « ${shorten(input.feedback, 300)} »`,
    ]);
  }

  return { content: renderSections(sections), summary: `${capitalize(actions.join(" ; "))}.` };
}
