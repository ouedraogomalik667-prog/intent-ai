export const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME ?? "IntentAI";

// Serveur uniquement : ne jamais importer cette fonction dans un composant client.
export function getAiProviderName(): string {
  return process.env.AI_PROVIDER ?? "mock";
}

export function getSupabaseConfig(): { url: string; anonKey: string } {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    throw new Error(
      "Variables Supabase manquantes : vérifie NEXT_PUBLIC_SUPABASE_URL et NEXT_PUBLIC_SUPABASE_ANON_KEY dans .env.local, puis relance npm run dev."
    );
  }

  return { url, anonKey };
}
