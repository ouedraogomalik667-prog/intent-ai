import type { Category } from "@/types";

export const CATEGORIES: Category[] = [
  { id: "learn", label: "Apprendre", emoji: "📚", description: "Comprendre un sujet ou progresser" },
  { id: "write", label: "Écrire", emoji: "✍️", description: "Textes, emails, articles, scripts" },
  { id: "image", label: "Créer une image", emoji: "🎨", description: "Affiches, visuels, illustrations" },
  { id: "video", label: "Créer une vidéo", emoji: "🎬", description: "Idées, scénarios, montages" },
  { id: "business", label: "Business", emoji: "💼", description: "Offres, stratégie, marketing" },
  { id: "code", label: "Programmer", emoji: "💻", description: "Code, sites, applications" },
  { id: "research", label: "Rechercher", emoji: "🔎", description: "Analyses, comparaisons, synthèses" },
  { id: "other", label: "Autre", emoji: "✨", description: "Tout le reste" },
];
