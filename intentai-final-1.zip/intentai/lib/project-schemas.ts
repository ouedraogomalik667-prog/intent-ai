import { z } from "zod";
import { categoryIdSchema } from "@/lib/ai/schemas";

export const projectIdSchema = z.string().uuid("Identifiant de projet invalide.");

export const createProjectSchema = z.object({
  category: categoryIdSchema,
  idea: z
    .string()
    .trim()
    .min(10, "Décris ton idée avec quelques mots de plus (10 caractères minimum).")
    .max(2000, "Ton idée est trop longue (2000 caractères maximum)."),
});

export const answersSchema = z.object({
  answers: z
    .array(
      z.string().trim().max(2000, "Une réponse est trop longue (2000 caractères maximum).")
    )
    .min(1)
    .max(3),
});
