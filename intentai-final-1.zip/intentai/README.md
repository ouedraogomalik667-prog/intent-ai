# IntentAI

« Tu sais ce que tu veux. Explique-le simplement. » IntentAI transforme une idée en instruction claire pour une IA.

## État du projet

Étapes 1 à 6 (parties 1 à 3) : base, Supabase + RLS, authentification, analyse d'intention, questions,
instruction optimisée (V1), feedback 👍/👎, amélioration en V2, V3, V4… et historique des versions.
Fournisseur IA : `MockAIProvider` uniquement (aucune clé API, aucun coût).
Ce ZIP n'a pas été compilé avec Next.js par son auteur : lance `npm run build` pour le vérifier.

## Démarrage (nouveau dossier)

1. `npm install`
2. Copie `.env.example` en `.env.local` et remplis `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
3. Dans Supabase (SQL Editor), exécute dans l'ordre :
   `supabase/migrations/001_init.sql` puis `supabase/migrations/002_improved_versions.sql` (une seule fois chacun).
4. Supabase > Authentication > URL Configuration : Site URL = `http://localhost:3000`,
   Redirect URLs = `http://localhost:3000/**`. Pour tester vite, désactive « Confirm email » (Providers > Email).
5. `npm run build` puis `npm run dev` et ouvre http://localhost:3000

## Si tu as déjà un projet qui fonctionne

Ne remplace pas `package.json`, `tsconfig.json`, `next.config.ts`, `postcss.config.mjs` ni `app/globals.css`.
Copie seulement : `app/`, `components/`, `lib/`, `types/`, `supabase/` et `middleware.ts`
(accepte d'écraser), puis `npm run build`.
Dépendances nécessaires : `@supabase/ssr`, `@supabase/supabase-js`, `lucide-react`, `zod`.

## Structure

- `lib/ai/` : abstraction AIProvider (`provider.ts`), `MockAIProvider` (`mock*.ts`), schémas Zod
- `lib/services/` : accès aux données (projets, instructions, feedback et versions)
- `app/api/projects/...` : routes serveur (création, analyse, questions, réponses, instruction, feedback)
- `components/project/` : formulaire, questions, instruction, `FeedbackPanel` (👍/👎), `InstructionWorkspace` et `VersionHistory` (versions)
- `lib/feedback-ui.ts` : validation du commentaire et messages d'erreur de l'interface
- `supabase/migrations/` : schéma SQL, RLS et fonction `create_improved_version`
