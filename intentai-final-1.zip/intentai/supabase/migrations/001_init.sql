-- IntentAI : schéma initial + Row Level Security

-- ========== Utilitaire : mise à jour automatique de updated_at ==========
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- ========== profiles ==========
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text,
  experience_level text not null default 'beginner'
    check (experience_level in ('beginner', 'intermediate', 'advanced')),
  goals text,
  preferences jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ========== projects ==========
create table public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  title text,
  category text not null
    check (category in ('learn','write','image','video','business','code','research','other')),
  original_idea text not null
    check (char_length(original_idea) between 1 and 4000),
  intent jsonb,
  status text not null default 'draft'
    check (status in ('draft', 'questioning', 'ready', 'completed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ========== project_messages ==========
create table public.project_messages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  role text not null check (role in ('assistant', 'user')),
  content text not null check (char_length(content) between 1 and 8000),
  created_at timestamptz not null default now()
);

-- ========== instructions (une par projet) ==========
create table public.instructions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null unique references public.projects (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  current_version integer not null default 1 check (current_version >= 1),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ========== instruction_versions ==========
create table public.instruction_versions (
  id uuid primary key default gen_random_uuid(),
  instruction_id uuid not null references public.instructions (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  version_number integer not null check (version_number >= 1),
  content text not null check (char_length(content) between 1 and 20000),
  change_summary text,
  created_at timestamptz not null default now(),
  unique (instruction_id, version_number)
);

-- ========== feedback (un retour par version) ==========
create table public.feedback (
  id uuid primary key default gen_random_uuid(),
  instruction_version_id uuid not null unique
    references public.instruction_versions (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  is_positive boolean not null,
  comment text check (char_length(comment) <= 4000),
  analysis jsonb,
  created_at timestamptz not null default now(),
  check (is_positive or char_length(coalesce(comment, '')) > 0)
);

-- ========== Index ==========
create index projects_user_created_idx on public.projects (user_id, created_at desc);
create index project_messages_project_idx on public.project_messages (project_id, created_at);
create index project_messages_user_idx on public.project_messages (user_id);
create index instructions_user_idx on public.instructions (user_id);
create index instruction_versions_user_idx on public.instruction_versions (user_id);
create index instruction_versions_instruction_idx
  on public.instruction_versions (instruction_id, version_number desc);
create index feedback_user_idx on public.feedback (user_id);

-- ========== Triggers updated_at ==========
create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();
create trigger projects_set_updated_at before update on public.projects
  for each row execute function public.set_updated_at();
create trigger instructions_set_updated_at before update on public.instructions
  for each row execute function public.set_updated_at();

-- ========== Création automatique du profil à l'inscription ==========
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1))
  );
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Profils pour d'éventuels utilisateurs déjà existants
insert into public.profiles (id)
select id from auth.users
on conflict (id) do nothing;

-- ========== Row Level Security ==========
alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.project_messages enable row level security;
alter table public.instructions enable row level security;
alter table public.instruction_versions enable row level security;
alter table public.feedback enable row level security;

-- Chaque politique "for all" couvre lecture, création, modification, suppression.
-- Aucune politique pour le rôle "anon" : un visiteur non connecté ne voit rien.

create policy "profiles_own" on public.profiles
  for all to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

create policy "projects_own" on public.projects
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- Pour les tables enfants, on vérifie aussi que le parent appartient à l'utilisateur
-- (empêche d'attacher des données au projet d'un autre).
create policy "project_messages_own" on public.project_messages
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.projects p
      where p.id = project_id and p.user_id = (select auth.uid())
    )
  );

create policy "instructions_own" on public.instructions
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.projects p
      where p.id = project_id and p.user_id = (select auth.uid())
    )
  );

create policy "instruction_versions_own" on public.instruction_versions
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.instructions i
      where i.id = instruction_id and i.user_id = (select auth.uid())
    )
  );

create policy "feedback_own" on public.feedback
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.instruction_versions v
      where v.id = instruction_version_id and v.user_id = (select auth.uid())
    )
  );
