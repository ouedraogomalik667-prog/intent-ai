-- Étape 6 : création atomique d'une version améliorée.
-- Tout réussit ensemble (feedback + version N+1 + current_version) ou rien n'est enregistré.
create or replace function public.create_improved_version(
  p_instruction_id uuid,
  p_base_version integer,
  p_comment text,
  p_analysis jsonb,
  p_content text,
  p_summary text
)
returns integer
language plpgsql
security invoker
set search_path = ''
as $$
declare
  v_user uuid := (select auth.uid());
  v_instruction public.instructions%rowtype;
  v_base_id uuid;
  v_next integer;
begin
  if v_user is null then
    raise exception 'not_authenticated';
  end if;

  -- Verrouille la ligne : deux appels simultanés passent l'un après l'autre.
  -- « security invoker » : la RLS ne montre que les instructions de l'utilisateur connecté.
  select * into v_instruction
  from public.instructions
  where id = p_instruction_id
  for update;

  if not found then
    raise exception 'instruction_not_found';
  end if;

  -- La version qui reçoit le retour doit être la version actuelle.
  if v_instruction.current_version <> p_base_version then
    raise exception 'version_conflict';
  end if;

  select v.id into v_base_id
  from public.instruction_versions v
  where v.instruction_id = p_instruction_id
    and v.version_number = p_base_version;

  if v_base_id is null then
    raise exception 'base_version_not_found';
  end if;

  v_next := p_base_version + 1;

  -- Le retour est lié à la version qui l'a reçu (une seule fois : contrainte unique).
  insert into public.feedback (instruction_version_id, user_id, is_positive, comment, analysis)
  values (v_base_id, v_user, false, p_comment, p_analysis);

  -- La nouvelle version s'ajoute : les anciennes ne sont jamais modifiées.
  insert into public.instruction_versions
    (instruction_id, user_id, version_number, content, change_summary)
  values
    (p_instruction_id, v_user, v_next, p_content, p_summary);

  update public.instructions
  set current_version = v_next
  where id = p_instruction_id;

  return v_next;
end;
$$;

revoke all on function public.create_improved_version(uuid, integer, text, jsonb, text, text)
  from public, anon;
grant execute on function public.create_improved_version(uuid, integer, text, jsonb, text, text)
  to authenticated;
