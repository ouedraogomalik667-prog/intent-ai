"use client";

import Link from "next/link";
import { useActionState } from "react";
import { login, signup } from "@/app/auth/actions";
import { Button } from "@/components/ui/Button";
import type { AuthState } from "@/types/auth";

const initialState: AuthState = {
  error: null,
  message: null,
  email: "",
  displayName: "",
};

const inputClass =
  "w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200";

interface AuthFormProps {
  mode: "login" | "signup";
  notice?: string;
}

export function AuthForm({ mode, notice }: AuthFormProps) {
  const isSignup = mode === "signup";
  const [state, formAction, pending] = useActionState(
    isSignup ? signup : login,
    initialState
  );

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-2">
        <h1 className="text-2xl font-bold">
          {isSignup ? "Créer ton compte" : "Content de te revoir"}
        </h1>
        <p className="text-sm text-zinc-600">
          {isSignup
            ? "Quelques secondes suffisent pour commencer."
            : "Connecte-toi pour retrouver tes projets."}
        </p>
      </div>

      <form action={formAction} className="flex flex-col gap-4">
        {isSignup && (
          <label className="flex flex-col gap-1 text-sm font-medium">
            Prénom
            <input
              name="displayName"
              type="text"
              required
              maxLength={50}
              autoComplete="given-name"
              defaultValue={state.displayName}
              className={inputClass}
            />
          </label>
        )}

        <label className="flex flex-col gap-1 text-sm font-medium">
          Email
          <input
            name="email"
            type="email"
            required
            autoComplete="email"
            defaultValue={state.email}
            className={inputClass}
          />
        </label>

        <label className="flex flex-col gap-1 text-sm font-medium">
          Mot de passe
          <input
            name="password"
            type="password"
            required
            minLength={isSignup ? 8 : undefined}
            autoComplete={isSignup ? "new-password" : "current-password"}
            className={inputClass}
          />
          {isSignup && (
            <span className="text-xs font-normal text-zinc-500">
              8 caractères minimum.
            </span>
          )}
        </label>

        {notice && !state.error && !state.message && (
          <p role="alert" className="rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-800">
            {notice}
          </p>
        )}
        {state.error && (
          <p role="alert" className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
            {state.error}
          </p>
        )}
        {state.message && (
          <p role="status" className="rounded-xl bg-green-50 px-4 py-3 text-sm text-green-700">
            {state.message}
          </p>
        )}

        <Button type="submit" disabled={pending}>
          {pending
            ? "Patiente..."
            : isSignup
              ? "Créer mon compte"
              : "Me connecter"}
        </Button>
      </form>

      <p className="text-center text-sm text-zinc-600">
        {isSignup ? (
          <>
            Déjà un compte ?{" "}
            <Link href="/login" className="font-medium text-indigo-600 hover:underline">
              Se connecter
            </Link>
          </>
        ) : (
          <>
            Pas encore de compte ?{" "}
            <Link href="/signup" className="font-medium text-indigo-600 hover:underline">
              S&apos;inscrire
            </Link>
          </>
        )}
      </p>
    </div>
  );
}
