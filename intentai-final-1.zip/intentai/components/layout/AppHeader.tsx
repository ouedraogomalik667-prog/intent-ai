import Link from "next/link";
import { LogoutButton } from "@/components/layout/LogoutButton";
import { APP_NAME } from "@/lib/env";

export function AppHeader({ email }: { email: string }) {
  return (
    <header className="border-b border-zinc-200">
      <div className="mx-auto flex max-w-3xl items-center justify-between gap-3 px-5 py-3">
        <Link href="/dashboard" className="font-semibold text-indigo-600">
          {APP_NAME}
        </Link>
        <div className="flex items-center gap-3">
          <span className="hidden text-sm text-zinc-500 sm:inline">{email}</span>
          <LogoutButton />
        </div>
      </div>
    </header>
  );
}
