import { logout } from "@/app/auth/actions";
import { Button } from "@/components/ui/Button";

export function LogoutButton() {
  return (
    <form action={logout}>
      <Button type="submit" variant="secondary" className="px-4 py-2">
        Se déconnecter
      </Button>
    </form>
  );
}
