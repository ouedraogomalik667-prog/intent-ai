"use client";

import { useRouter } from "next/navigation";
import { useRef, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/Button";
import {
  COMMENT_MAX,
  describeFeedbackError,
  isVersionConflict,
  validateComment,
  type FeedbackApiResponse,
} from "@/lib/feedback-ui";

type Mode = "choice" | "form" | "validated";

type FeedbackPayload =
  | { isPositive: true; versionNumber: number }
  | { isPositive: false; versionNumber: number; comment: string };

const EXAMPLES = [
  "Le ton est trop professionnel.",
  "Je veux quelque chose de plus court.",
  "L'instruction ne correspond pas à mon public.",
  "Il manque des informations importantes.",
];

interface FeedbackPanelProps {
  projectId: string;
  versionNumber: number;
  initiallyValidated: boolean;
}

export function FeedbackPanel({ projectId, versionNumber, initiallyValidated }: FeedbackPanelProps) {
  const router = useRouter();
  const lockRef = useRef(false); // bloque les doubles clics, même avant le re-rendu
  const [mode, setMode] = useState<Mode>(initiallyValidated ? "validated" : "choice");
  const [comment, setComment] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stale, setStale] = useState(false);

  // Envoie le feedback à l'API (toute la logique reste côté serveur). Vrai si succès.
  async function send(payload: FeedbackPayload): Promise<boolean> {
    if (lockRef.current) return false;
    lockRef.current = true;
    setPending(true);
    setError(null);
    setStale(false);
    try {
      const response = await fetch(`/api/projects/${projectId}/feedback`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data: FeedbackApiResponse = await response.json().catch(() => ({}));
      if (!response.ok) {
        setError(describeFeedbackError(response.status, data));
        setStale(isVersionConflict(data));
        lockRef.current = false;
        setPending(false);
        return false;
      }
      return true;
    } catch {
      setError("Connexion impossible. Vérifie ta connexion internet et réessaie.");
      lockRef.current = false;
      setPending(false);
      return false;
    }
  }

  async function handlePositive() {
    if (await send({ isPositive: true, versionNumber })) {
      setMode("validated");
      setPending(false);
      router.refresh();
    }
  }

  async function handleImprove(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const problem = validateComment(comment);
    if (problem) {
      setError(problem);
      return;
    }
    // En cas de succès, la page se recharge sur la nouvelle version (ce composant est remplacé).
    if (await send({ isPositive: false, versionNumber, comment: comment.trim() })) {
      router.refresh();
    }
  }

  if (mode === "validated") {
    return (
      <p role="status" className="rounded-2xl bg-green-50 p-5 text-sm font-medium text-green-800">
        ✓ Parfait ! Cette instruction est validée.
      </p>
    );
  }

  const errorBlock = error && (
    <div role="alert" className="flex flex-col gap-2 rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
      <span>{error}</span>
      {stale && (
        <button
          type="button"
          onClick={() => router.refresh()}
          className="self-start font-medium underline focus:outline-none focus-visible:ring-2 focus-visible:ring-red-400"
        >
          Recharger la version actuelle
        </button>
      )}
    </div>
  );

  if (mode === "choice") {
    return (
      <section className="flex flex-col gap-4 rounded-2xl border border-zinc-200 p-5">
        <h3 className="font-semibold">Cette instruction te convient-elle ?</h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={handlePositive}
            disabled={pending}
            className="rounded-xl border border-green-600 px-4 py-3 text-sm font-medium text-green-800 transition-colors hover:bg-green-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-green-500 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {pending ? "Enregistrement..." : "👍 Oui, elle me convient"}
          </button>
          <button
            type="button"
            onClick={() => {
              setError(null);
              setMode("form");
            }}
            disabled={pending}
            className="rounded-xl border border-zinc-300 px-4 py-3 text-sm font-medium text-zinc-800 transition-colors hover:bg-zinc-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 disabled:cursor-not-allowed disabled:opacity-50"
          >
            👎 Non, je veux l&apos;améliorer
          </button>
        </div>
        {errorBlock}
      </section>
    );
  }

  return (
    <form onSubmit={handleImprove} className="flex flex-col gap-4 rounded-2xl border border-zinc-200 p-5">
      <label htmlFor="feedback-comment" className="font-semibold">
        Qu&apos;est-ce qui ne va pas avec cette instruction ?
      </label>
      <p className="-mt-2 text-sm text-zinc-600">
        Explique simplement ce qui manque, ce qui est incorrect ou ce que tu voudrais changer.
      </p>
      <div className="flex flex-wrap gap-2">
        {EXAMPLES.map((example) => (
          <button
            key={example}
            type="button"
            disabled={pending}
            onClick={() => setComment(example)}
            className="rounded-full border border-zinc-300 px-3 py-1 text-xs transition-colors hover:border-zinc-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 disabled:opacity-60"
          >
            {example}
          </button>
        ))}
      </div>
      <textarea
        id="feedback-comment"
        value={comment}
        onChange={(event) => setComment(event.target.value)}
        disabled={pending}
        rows={4}
        maxLength={COMMENT_MAX}
        placeholder="Exemple : le ton est trop professionnel, je veux quelque chose de plus simple et adapté aux débutants."
        className="w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 disabled:opacity-60"
      />
      <span className="-mt-2 text-right text-xs text-zinc-500">
        {comment.length}/{COMMENT_MAX}
      </span>

      {errorBlock}

      {pending ? (
        <div role="status" className="flex items-center gap-3 text-sm text-zinc-700">
          <span className="h-5 w-5 animate-spin rounded-full border-2 border-indigo-200 border-t-indigo-600" />
          Analyse de ton retour et amélioration de l&apos;instruction...
        </div>
      ) : (
        <div className="flex flex-wrap gap-3">
          <Button type="submit" disabled={validateComment(comment) !== null}>
            Améliorer l&apos;instruction
          </Button>
          <Button
            type="button"
            variant="secondary"
            onClick={() => {
              setError(null);
              setComment("");
              setMode("choice");
            }}
          >
            Annuler
          </Button>
        </div>
      )}
    </form>
  );
}
