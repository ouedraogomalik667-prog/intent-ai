"use client";

import type { VersionHistoryItem } from "@/lib/services/feedback";

interface VersionHistoryProps {
  versions: VersionHistoryItem[];
  currentVersion: number;
  selected: number;
  onSelect: (versionNumber: number) => void;
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleString("fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function VersionHistory({ versions, currentVersion, selected, onSelect }: VersionHistoryProps) {
  const ordered = [...versions].sort((a, b) => b.versionNumber - a.versionNumber);

  return (
    <section className="flex flex-col gap-3 rounded-2xl border border-zinc-200 p-5">
      <h3 className="font-semibold">Historique des versions</h3>
      <ul className="flex flex-col gap-2">
        {ordered.map((version) => {
          const isCurrent = version.versionNumber === currentVersion;
          const isSelected = version.versionNumber === selected;
          return (
            <li key={version.versionNumber}>
              <button
                type="button"
                onClick={() => onSelect(version.versionNumber)}
                aria-current={isSelected ? "true" : undefined}
                className={`flex w-full flex-col gap-1 rounded-xl border p-3 text-left text-sm transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 ${
                  isSelected ? "border-indigo-600 bg-indigo-50" : "border-zinc-200 hover:border-zinc-400"
                }`}
              >
                <span className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">Version {version.versionNumber}</span>
                  {isCurrent && (
                    <span className="rounded-full bg-indigo-600 px-2 py-0.5 text-xs text-white">
                      Version actuelle
                    </span>
                  )}
                  {version.feedback?.isPositive === true && (
                    <span className="rounded-full bg-green-100 px-2 py-0.5 text-xs text-green-800">
                      ✓ Validée
                    </span>
                  )}
                  {version.feedback?.isPositive === false && (
                    <span className="rounded-full bg-zinc-100 px-2 py-0.5 text-xs text-zinc-700">
                      Améliorée
                    </span>
                  )}
                </span>
                <time dateTime={version.createdAt} suppressHydrationWarning className="text-xs text-zinc-500">
                  {formatDate(version.createdAt)}
                </time>
                {version.changeSummary && (
                  <span className="text-xs text-zinc-600">{version.changeSummary}</span>
                )}
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
