"use client";

import { useState } from "react";
import { FeedbackPanel } from "@/components/project/FeedbackPanel";
import { InstructionCard } from "@/components/project/InstructionCard";
import { VersionHistory } from "@/components/project/VersionHistory";
import { splitSummary } from "@/lib/feedback-ui";
import type { VersionHistoryItem } from "@/lib/services/feedback";

interface InstructionWorkspaceProps {
  projectId: string;
  currentVersion: number; // vient de Supabase (instructions.current_version)
  versions: VersionHistoryItem[];
}

export function InstructionWorkspace({ projectId, currentVersion, versions }: InstructionWorkspaceProps) {
  // La sélection ne sert qu'à LIRE une ancienne version : elle ne modifie jamais current_version.
  const [selected, setSelected] = useState(currentVersion);

  const current = versions.find((v) => v.versionNumber === currentVersion);
  const shown = versions.find((v) => v.versionNumber === selected) ?? current;
  if (!shown || !current) return null;

  const isCurrent = shown.versionNumber === currentVersion;
  const improvements = shown.versionNumber > 1 ? splitSummary(shown.changeSummary) : [];

  return (
    <div className="flex flex-col gap-6">
      {!isCurrent && (
        <div className="flex flex-col gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900">
          <p>
            Cette version est historique (lecture seule). La version actuelle est V{currentVersion}.
          </p>
          <div>
            <button
              type="button"
              onClick={() => setSelected(currentVersion)}
              className="rounded-xl border border-amber-400 px-4 py-2 font-medium transition-colors hover:bg-amber-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500"
            >
              Revenir à la version actuelle
            </button>
          </div>
        </div>
      )}

      {improvements.length > 0 && (
        <section className="flex flex-col gap-2 rounded-2xl bg-indigo-50 p-5 text-sm">
          <h3 className="font-semibold text-indigo-900">Améliorations apportées</h3>
          <ul className="list-disc pl-5 text-indigo-900">
            {improvements.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </section>
      )}

      <InstructionCard content={shown.content} versionNumber={shown.versionNumber} />

      {isCurrent && (
        <FeedbackPanel
          projectId={projectId}
          versionNumber={currentVersion}
          initiallyValidated={current.feedback?.isPositive === true}
        />
      )}

      <VersionHistory
        versions={versions}
        currentVersion={currentVersion}
        selected={shown.versionNumber}
        onSelect={setSelected}
      />
    </div>
  );
}
