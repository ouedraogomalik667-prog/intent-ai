"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/Button";
import type { Question } from "@/lib/ai/types";

interface QuestionsFormProps {
  projectId: string;
  questions: Question[];
}

export function QuestionsForm({ projectId, questions }: QuestionsFormProps) {
  const router = useRouter();
  const [answers, setAnswers] = useState<string[]>(() => questions.map(() => ""));
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function setAnswer(index: number, value: string) {
    setAnswers((current) => current.map((answer, i) => (i === index ? value : answer)));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError(null);
    try {
      const response = await fetch(`/api/projects/${projectId}/answers`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers }),
      });
      if (!response.ok) {
        const data: { error?: string } = await response.json().catch(() => ({}));
        setError(data.error ?? "Impossible d'enregistrer tes réponses.");
        setPending(false);
        return;
      }
      router.refresh();
    } catch {
      setError("Connexion impossible. Vérifie ta connexion internet et réessaie.");
      setPending(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
      <div className="flex flex-col gap-1">
        <h2 className="font-semibold">
          {questions.length > 1 ? `${questions.length} petites questions` : "Une petite question"}
        </h2>
        <p className="text-sm text-zinc-600">
          Tu peux laisser une réponse vide si tu n&apos;as pas de préférence.
        </p>
      </div>

      {questions.map((question, index) => (
        <div key={question.id} className="flex flex-col gap-2 rounded-2xl border border-zinc-200 p-4">
          <label htmlFor={`answer-${index}`} className="text-sm font-medium">
            {index + 1}. {question.text}
          </label>
          {question.hint && <p className="text-xs text-zinc-500">{question.hint}</p>}

          {question.suggestions.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {question.suggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  disabled={pending}
                  onClick={() => setAnswer(index, suggestion)}
                  className={`rounded-full border px-3 py-1 text-xs transition-colors disabled:opacity-60 ${
                    answers[index] === suggestion
                      ? "border-indigo-600 bg-indigo-50 text-indigo-800"
                      : "border-zinc-300 hover:border-zinc-500"
                  }`}
                >
                  {suggestion}
                </button>
              ))}
            </div>
          )}

          <textarea
            id={`answer-${index}`}
            value={answers[index] ?? ""}
            onChange={(event) => setAnswer(index, event.target.value)}
            disabled={pending}
            rows={2}
            maxLength={2000}
            className="w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 disabled:opacity-60"
          />
        </div>
      ))}

      {error && (
        <p role="alert" className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </p>
      )}

      <Button type="submit" disabled={pending}>
        {pending ? "Enregistrement..." : "Continuer"}
      </Button>
    </form>
  );
}
