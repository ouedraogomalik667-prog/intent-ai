import type { IntentAnalysis } from "@/lib/ai/types";

export function IntentSummary({ analysis }: { analysis: IntentAnalysis }) {
  const rows: Array<{ label: string; value: string | null }> = [
    { label: "Objectif", value: analysis.objective },
    { label: "Contexte", value: analysis.context },
    { label: "Format", value: analysis.format },
    { label: "Résultat attendu", value: analysis.expectedResult },
    { label: "Public", value: analysis.audience },
    { label: "Style", value: analysis.style },
    {
      label: "Contraintes",
      value: analysis.constraints.length > 0 ? analysis.constraints.join(", ") : null,
    },
  ];

  return (
    <section className="flex flex-col gap-4 rounded-2xl border border-zinc-200 p-5">
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-semibold">Ce que j&apos;ai compris</h2>
        <span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-medium text-indigo-700">
          Compréhension : {Math.round(analysis.confidence * 100)} %
        </span>
      </div>
      <dl className="flex flex-col gap-3 text-sm">
        {rows.map((row) =>
          row.value ? (
            <div key={row.label} className="flex flex-col gap-0.5">
              <dt className="text-xs font-medium uppercase tracking-wide text-zinc-500">
                {row.label}
              </dt>
              <dd>{row.value}</dd>
            </div>
          ) : null
        )}
      </dl>
    </section>
  );
}
