"use client";

import { useEffect, useRef, useState } from "react";

type CopyState = "idle" | "copied" | "error";

async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    // Solution de secours pour les navigateurs qui refusent l'API moderne.
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "");
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(area);
      return ok;
    } catch {
      return false;
    }
  }
}

interface InstructionCardProps {
  content: string;
  versionNumber: number;
}

export function InstructionCard({ content, versionNumber }: InstructionCardProps) {
  const [state, setState] = useState<CopyState>("idle");
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  async function handleCopy() {
    const ok = await copyText(content);
    setState(ok ? "copied" : "error");
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setState("idle"), 2500);
  }

  return (
    <section className="flex flex-col gap-4 rounded-2xl border border-indigo-200 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-bold">Ton instruction optimisée</h2>
        <span className="rounded-full bg-indigo-50 px-3 py-1 text-xs font-medium text-indigo-700">
          Version {versionNumber}
        </span>
      </div>

      <p className="text-sm text-zinc-600">
        Copie-la, puis colle-la dans ChatGPT, Gemini, Claude ou n&apos;importe quelle autre IA.
      </p>

      <button
        type="button"
        onClick={handleCopy}
        className={`rounded-xl px-5 py-3 text-sm font-medium transition-colors ${
          state === "copied"
            ? "bg-green-600 text-white"
            : "bg-indigo-600 text-white hover:bg-indigo-500"
        }`}
      >
        {state === "copied" ? "✓ Copié !" : "Copier l'instruction"}
      </button>

      <p role="status" className="min-h-5 text-sm">
        {state === "copied" && (
          <span className="text-green-700">Instruction copiée dans ton presse-papiers.</span>
        )}
        {state === "error" && (
          <span className="text-red-700">
            Copie impossible. Sélectionne le texte ci-dessous et copie-le à la main.
          </span>
        )}
      </p>

      <pre className="whitespace-pre-wrap break-words rounded-xl bg-zinc-50 p-4 font-sans text-sm leading-relaxed text-zinc-800">
        {content}
      </pre>
    </section>
  );
}
