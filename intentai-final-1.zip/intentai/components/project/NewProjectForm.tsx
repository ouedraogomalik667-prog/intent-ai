"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { CategoryPicker } from "@/components/project/CategoryPicker";
import { Button } from "@/components/ui/Button";
import type { CategoryId } from "@/types";

const MAX_LENGTH = 2000;

export function NewProjectForm() {
  const router = useRouter();
  const [category, setCategory] = useState<CategoryId | null>(null);
  const [idea, setIdea] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canSubmit = category !== null && idea.trim().length >= 10 && !pending;

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!category) return;

    setPending(true);
    setError(null);
    try {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ category, idea }),
      });
      const data: { id?: string; error?: string } = await response.json();
      if (!response.ok || !data.id) {
        setError(data.error ?? "Impossible de créer le projet.");
        setPending(false);
        return;
      }
      router.push(`/projects/${data.id}`);
    } catch {
      setError("Connexion impossible. Vérifie ta connexion internet et réessaie.");
      setPending(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <div className="flex flex-col gap-2">
        <span className="text-sm font-medium">1. Que veux-tu faire ?</span>
        <CategoryPicker value={category} onChange={setCategory} disabled={pending} />
      </div>

      <div className="flex flex-col gap-2">
        <label htmlFor="idea" className="text-sm font-medium">
          2. Explique ton idée avec tes mots
        </label>
        <textarea
          id="idea"
          value={idea}
          onChange={(event) => setIdea(event.target.value)}
          disabled={pending}
          rows={5}
          maxLength={MAX_LENGTH}
          placeholder="Ex. : Je veux créer une vidéo TikTok pour vendre mes chaussures noires à Ouagadougou."
          className="w-full rounded-xl border border-zinc-300 px-4 py-3 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 disabled:opacity-60"
        />
        <span className="text-right text-xs text-zinc-500">
          {idea.length}/{MAX_LENGTH}
        </span>
      </div>

      {error && (
        <p role="alert" className="rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700">
          {error}
        </p>
      )}

      <Button type="submit" disabled={!canSubmit}>
        {pending ? "Création du projet..." : "Analyser mon idée"}
      </Button>
    </form>
  );
}
