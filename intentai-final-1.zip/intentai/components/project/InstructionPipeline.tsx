"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/Button";

export function InstructionPipeline({ projectId }: { projectId: string }) {
  const router = useRouter();
  const startedRef = useRef(false);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async () => {
    try {
      const response = await fetch(`/api/projects/${projectId}/instruction`, {
        method: "POST",
      });
      if (!response.ok) {
        let message = "Une erreur est survenue.";
        try {
          const data: { error?: string } = await response.json();
          if (data.error) message = data.error;
        } catch {
          // Réponse non lisible : on garde le message par défaut.
        }
        throw new Error(message);
      }
      router.refresh();
    } catch (caught) {
      if (caught instanceof TypeError) {
        setError("Connexion impossible. Vérifie ta connexion internet et réessaie.");
      } else {
        setError(caught instanceof Error ? caught.message : "Une erreur est survenue.");
      }
    }
  }, [projectId, router]);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    void run();
  }, [run]);

  function handleRetry() {
    setError(null);
    void run();
  }

  if (error) {
    return (
      <div className="flex flex-col gap-3 rounded-2xl border border-red-200 bg-red-50 p-5">
        <p role="alert" className="text-sm text-red-700">
          {error}
        </p>
        <div>
          <Button variant="secondary" onClick={handleRetry}>
            Réessayer
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      role="status"
      className="flex items-center gap-3 rounded-2xl border border-zinc-200 p-5 text-sm text-zinc-700"
    >
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-indigo-200 border-t-indigo-600" />
      Création de ton instruction...
    </div>
  );
}
