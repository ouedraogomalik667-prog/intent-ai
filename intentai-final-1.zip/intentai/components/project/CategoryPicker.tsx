"use client";

import { CATEGORIES } from "@/lib/constants";
import type { CategoryId } from "@/types";

interface CategoryPickerProps {
  value: CategoryId | null;
  onChange: (id: CategoryId) => void;
  disabled?: boolean;
}

export function CategoryPicker({ value, onChange, disabled = false }: CategoryPickerProps) {
  return (
    <div
      role="radiogroup"
      aria-label="Catégorie"
      className="grid grid-cols-2 gap-2 sm:grid-cols-4"
    >
      {CATEGORIES.map((category) => {
        const selected = category.id === value;
        return (
          <button
            key={category.id}
            type="button"
            role="radio"
            aria-checked={selected}
            disabled={disabled}
            onClick={() => onChange(category.id)}
            className={`flex flex-col items-start gap-1 rounded-2xl border p-3 text-left text-sm transition-colors disabled:opacity-60 ${
              selected
                ? "border-indigo-600 bg-indigo-50 text-indigo-900"
                : "border-zinc-200 hover:border-zinc-400"
            }`}
          >
            <span className="text-xl">{category.emoji}</span>
            <span className="font-medium">{category.label}</span>
          </button>
        );
      })}
    </div>
  );
}
