"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/Button";

type Step = "analyzing" | "questions";

async function post(url: string): Promise<void> {
  const response = await fetch(url, { method: "POST" });
  if (!response.ok) {
    let message = "Une erreur est survenue.";
    try {
      const data: { error?: string } = await response.json();
      if (data.error) message = data.error;
    } catch {
      // Réponse non lisible : on garde le message par défaut.
    }
    throw new Error(message);
  }
}

interface AnalysisPipelineProps {
  projectId: string;
  needsAnalysis: boolean;
}

export function AnalysisPipeline({ projectId, needsAnalysis }: AnalysisPipelineProps) {
  const router = useRouter();
  const startedRef = useRef(false);
  const initialStep: Step = needsAnalysis ? "analyzing" : "questions";
  const [step, setStep] = useState<Step>(initialStep);
  const [error, setError] = useState<string | null>(null);

  const run = useCallback(async () => {
    try {
      if (needsAnalysis) {
        await post(`/api/projects/${projectId}/analyze`);
      }
      setStep("questions");
      await post(`/api/projects/${projectId}/questions`);
      router.refresh();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Une erreur est survenue.");
    }
  }, [needsAnalysis, projectId, router]);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;
    void run();
  }, [run]);

  function handleRetry() {
    setError(null);
    setStep(initialStep);
    void run();
  }

  if (error) {
    return (
      <div className="flex flex-col gap-3 rounded-2xl border border-red-200 bg-red-50 p-5">
        <p role="alert" className="text-sm text-red-700">
          {error}
        </p>
        <div>
          <Button variant="secondary" onClick={handleRetry}>
            Réessayer
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      role="status"
      className="flex items-center gap-3 rounded-2xl border border-zinc-200 p-5 text-sm text-zinc-700"
    >
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-indigo-200 border-t-indigo-600" />
      {step === "analyzing" ? "Analyse de ton idée..." : "Préparation des questions..."}
    </div>
  );
}
