export type CategoryId =
  | "learn"
  | "write"
  | "image"
  | "video"
  | "business"
  | "code"
  | "research"
  | "other";

export interface Category {
  id: CategoryId;
  label: string;
  emoji: string;
  description: string;
}
