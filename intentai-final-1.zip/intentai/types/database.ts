import type { CategoryId } from "@/types";

export type ExperienceLevel = "beginner" | "intermediate" | "advanced";
export type ProjectStatus = "draft" | "questioning" | "ready" | "completed";
export type MessageRole = "assistant" | "user";

export interface Profile {
  id: string;
  display_name: string | null;
  experience_level: ExperienceLevel;
  goals: string | null;
  preferences: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  user_id: string;
  title: string | null;
  category: CategoryId;
  original_idea: string;
  intent: Record<string, unknown> | null;
  status: ProjectStatus;
  created_at: string;
  updated_at: string;
}

export interface ProjectMessage {
  id: string;
  project_id: string;
  user_id: string;
  role: MessageRole;
  content: string;
  created_at: string;
}

export interface Instruction {
  id: string;
  project_id: string;
  user_id: string;
  current_version: number;
  created_at: string;
  updated_at: string;
}

export interface InstructionVersion {
  id: string;
  instruction_id: string;
  user_id: string;
  version_number: number;
  content: string;
  change_summary: string | null;
  created_at: string;
}

export interface Feedback {
  id: string;
  instruction_version_id: string;
  user_id: string;
  is_positive: boolean;
  comment: string | null;
  analysis: Record<string, unknown> | null;
  created_at: string;
}
