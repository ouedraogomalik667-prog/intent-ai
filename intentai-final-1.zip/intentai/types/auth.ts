export interface AuthState {
  error: string | null;
  message: string | null;
  email: string;
  displayName: string;
}
